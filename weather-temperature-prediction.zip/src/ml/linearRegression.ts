import * as tf from '@tensorflow/tfjs';
import { ScalerParams, transformWithScaler } from './featureEngineering';

export interface LinearRegressionModel {
  weights: number[]; // coefficient per feature
  bias: number;
  featureNames: string[];
  scaler: ScalerParams;
  coefficients: { feature: string; coefficient: number; influence: number }[];
  predict: (features: number[]) => number;
}

// Solves (X^T * X + lambda * I) * w = X^T * y
function solveRidge(X: number[][], y: number[], lambda: number = 1e-4): { weights: number[]; bias: number } {
  const n = X.length;
  const p = X[0].length;

  // Add bias column of 1s as first column
  const Xb: number[][] = X.map((row) => [1, ...row]);
  const pTotal = p + 1;

  // Compute X^T * X
  const XtX: number[][] = Array.from({ length: pTotal }, () => new Array(pTotal).fill(0));
  for (let i = 0; i < n; i++) {
    const row = Xb[i];
    for (let j = 0; j < pTotal; j++) {
      const valJ = row[j];
      for (let k = 0; k < pTotal; k++) {
        XtX[j][k] += valJ * row[k];
      }
    }
  }

  // Add ridge penalty to non-bias terms
  for (let j = 1; j < pTotal; j++) {
    XtX[j][j] += lambda;
  }

  // Compute X^T * y
  const Xty: number[] = new Array(pTotal).fill(0);
  for (let i = 0; i < n; i++) {
    const row = Xb[i];
    const target = y[i];
    for (let j = 0; j < pTotal; j++) {
      Xty[j] += row[j] * target;
    }
  }

  // Solve XtX * beta = Xty using Gaussian elimination with partial pivoting
  const A = XtX.map((r) => [...r]);
  const b = [...Xty];

  for (let i = 0; i < pTotal; i++) {
    // Pivot
    let maxRow = i;
    for (let k = i + 1; k < pTotal; k++) {
      if (Math.abs(A[k][i]) > Math.abs(A[maxRow][i])) {
        maxRow = k;
      }
    }

    // Swap
    [A[i], A[maxRow]] = [A[maxRow], A[i]];
    [b[i], b[maxRow]] = [b[maxRow], b[i]];

    const pivot = A[i][i];
    if (Math.abs(pivot) < 1e-12) continue;

    for (let k = i + 1; k < pTotal; k++) {
      const factor = A[k][i] / pivot;
      b[k] -= factor * b[i];
      for (let j = i; j < pTotal; j++) {
        A[k][j] -= factor * A[i][j];
      }
    }
  }

  // Back substitution
  const beta: number[] = new Array(pTotal).fill(0);
  for (let i = pTotal - 1; i >= 0; i--) {
    let sum = 0;
    for (let j = i + 1; j < pTotal; j++) {
      sum += A[i][j] * beta[j];
    }
    const diag = A[i][i];
    beta[i] = Math.abs(diag) > 1e-12 ? (b[i] - sum) / diag : 0;
  }

  const bias = beta[0];
  const weights = beta.slice(1);

  return { weights, bias };
}

export function trainLinearRegression(
  X_train_raw: number[][],
  y_train: number[],
  scaler: ScalerParams,
  featureNames: string[]
): LinearRegressionModel {
  // Transform training features
  const X_norm = X_train_raw.map((row) => transformWithScaler(row, scaler));
  const { weights, bias } = solveRidge(X_norm, y_train);

  // Compute normalized relative influence
  const absSum = weights.reduce((acc, w) => acc + Math.abs(w), 0) || 1;
  const coefficients = featureNames.map((name, idx) => ({
    feature: name,
    coefficient: Number(weights[idx].toFixed(4)),
    influence: Number(((Math.abs(weights[idx]) / absSum) * 100).toFixed(1)),
  }));

  // Sort by absolute coefficient magnitude for reporting
  coefficients.sort((a, b) => Math.abs(b.coefficient) - Math.abs(a.coefficient));

  // Predict function using TensorFlow.js tensor math for fast verified vector-matrix operation
  const predict = (rawFeatures: number[]): number => {
    const norm = transformWithScaler(rawFeatures, scaler);
    
    // Use TensorFlow.js tidy to execute vector dot product cleanly
    const predictionVal = tf.tidy(() => {
      const xTensor = tf.tensor1d(norm);
      const wTensor = tf.tensor1d(weights);
      const dot = xTensor.dot(wTensor);
      return dot.dataSync()[0] + bias;
    });

    return Number(predictionVal.toFixed(1));
  };

  return {
    weights,
    bias,
    featureNames,
    scaler,
    coefficients,
    predict,
  };
}
