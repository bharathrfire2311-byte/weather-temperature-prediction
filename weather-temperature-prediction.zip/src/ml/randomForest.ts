import { FeatureImportanceItem } from '../types';

interface TreeNode {
  isLeaf: boolean;
  value?: number;
  featureIndex?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
}

class DecisionTreeRegressor {
  maxDepth: number;
  minSamplesSplit: number;
  root: TreeNode | null = null;
  featureImportances: number[];

  constructor(maxDepth = 6, minSamplesSplit = 4, numFeatures = 13) {
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
    this.featureImportances = new Array(numFeatures).fill(0);
  }

  private calculateVariance(y: number[]): number {
    const n = y.length;
    if (n <= 1) return 0;
    const mean = y.reduce((a, b) => a + b, 0) / n;
    let sumSq = 0;
    for (let i = 0; i < n; i++) {
      sumSq += Math.pow(y[i] - mean, 2);
    }
    return sumSq / n;
  }

  train(X: number[][], y: number[]) {
    const numFeatures = X[0].length;
    this.featureImportances = new Array(numFeatures).fill(0);
    this.root = this.buildTree(X, y, 0);
  }

  private buildTree(X: number[][], y: number[], depth: number): TreeNode {
    const n = y.length;
    const mean = y.reduce((a, b) => a + b, 0) / n;

    if (depth >= this.maxDepth || n < this.minSamplesSplit) {
      return { isLeaf: true, value: mean };
    }

    const currentVar = this.calculateVariance(y);
    if (currentVar < 1e-6) {
      return { isLeaf: true, value: mean };
    }

    const numFeatures = X[0].length;
    // Subsample features (mtry)
    const mtry = Math.max(3, Math.floor(Math.sqrt(numFeatures)) + 2);
    const featureIndices: number[] = [];
    while (featureIndices.length < mtry) {
      const idx = Math.floor(Math.random() * numFeatures);
      if (!featureIndices.includes(idx)) {
        featureIndices.push(idx);
      }
    }

    let bestGain = -Infinity;
    let bestFeature = -1;
    let bestThreshold = 0;
    let bestLeftIndices: number[] = [];
    let bestRightIndices: number[] = [];

    for (const featIdx of featureIndices) {
      const vals = X.map((row) => row[featIdx]);
      // Sort unique values and test midpoints
      const uniqueSorted = Array.from(new Set(vals)).sort((a, b) => a - b);
      if (uniqueSorted.length <= 1) continue;

      // Sample up to 10 split points for speed and stability
      const step = Math.max(1, Math.floor(uniqueSorted.length / 10));
      for (let s = 0; s < uniqueSorted.length - 1; s += step) {
        const threshold = (uniqueSorted[s] + uniqueSorted[s + 1]) / 2;

        const leftIdx: number[] = [];
        const rightIdx: number[] = [];
        const leftY: number[] = [];
        const rightY: number[] = [];

        for (let i = 0; i < n; i++) {
          if (X[i][featIdx] <= threshold) {
            leftIdx.push(i);
            leftY.push(y[i]);
          } else {
            rightIdx.push(i);
            rightY.push(y[i]);
          }
        }

        if (leftY.length === 0 || rightY.length === 0) continue;

        const leftVar = this.calculateVariance(leftY);
        const rightVar = this.calculateVariance(rightY);

        // Variance reduction
        const gain = currentVar - (leftY.length / n) * leftVar - (rightY.length / n) * rightVar;

        if (gain > bestGain) {
          bestGain = gain;
          bestFeature = featIdx;
          bestThreshold = threshold;
          bestLeftIndices = leftIdx;
          bestRightIndices = rightIdx;
        }
      }
    }

    if (bestGain <= 1e-5 || bestLeftIndices.length === 0 || bestRightIndices.length === 0) {
      return { isLeaf: true, value: mean };
    }

    // Accumulate importance (gain * sample count)
    this.featureImportances[bestFeature] += bestGain * n;

    const leftX = bestLeftIndices.map((i) => X[i]);
    const leftY = bestLeftIndices.map((i) => y[i]);
    const rightX = bestRightIndices.map((i) => X[i]);
    const rightY = bestRightIndices.map((i) => y[i]);

    return {
      isLeaf: false,
      featureIndex: bestFeature,
      threshold: bestThreshold,
      left: this.buildTree(leftX, leftY, depth + 1),
      right: this.buildTree(rightX, rightY, depth + 1),
    };
  }

  predictSingle(x: number[]): number {
    let node = this.root;
    while (node && !node.isLeaf) {
      if (node.featureIndex === undefined || node.threshold === undefined) break;
      if (x[node.featureIndex] <= node.threshold) {
        node = node.left || null;
      } else {
        node = node.right || null;
      }
    }
    return node?.value ?? 0;
  }
}

export interface RandomForestModel {
  trees: DecisionTreeRegressor[];
  featureNames: string[];
  featureImportance: FeatureImportanceItem[];
  predict: (features: number[]) => number;
}

export function trainRandomForest(
  X_train: number[][],
  y_train: number[],
  featureNames: string[],
  numTrees = 15
): RandomForestModel {
  const n = X_train.length;
  const numFeatures = featureNames.length;
  const trees: DecisionTreeRegressor[] = [];
  const aggregatedImportance: number[] = new Array(numFeatures).fill(0);

  for (let t = 0; t < numTrees; t++) {
    const tree = new DecisionTreeRegressor(6, 4, numFeatures);

    // Bootstrap sample (with replacement)
    const sampleIndices: number[] = [];
    for (let i = 0; i < n; i++) {
      sampleIndices.push(Math.floor(Math.random() * n));
    }

    const X_sample = sampleIndices.map((idx) => X_train[idx]);
    const y_sample = sampleIndices.map((idx) => y_train[idx]);

    tree.train(X_sample, y_sample);
    trees.push(tree);

    for (let f = 0; f < numFeatures; f++) {
      aggregatedImportance[f] += tree.featureImportances[f];
    }
  }

  // Normalize feature importance to percentage
  const totalImp = aggregatedImportance.reduce((a, b) => a + b, 0) || 1;
  const featureImportance: FeatureImportanceItem[] = featureNames.map((name, idx) => ({
    feature: name,
    importance: Number(((aggregatedImportance[idx] / totalImp) * 100).toFixed(1)),
  }));

  // Sort by importance descending
  featureImportance.sort((a, b) => b.importance - a.importance);

  const predict = (features: number[]): number => {
    let sum = 0;
    for (const tree of trees) {
      sum += tree.predictSingle(features);
    }
    return Number((sum / trees.length).toFixed(1));
  };

  return {
    trees,
    featureNames,
    featureImportance,
    predict,
  };
}
