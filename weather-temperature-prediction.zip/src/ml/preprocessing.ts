import { RawWeatherRecord, CleanWeatherRecord, DatasetSummary, Season } from '../types';
import { normalizeSeason, SEASONS } from './encoding';

export interface PreprocessingResult {
  cleanRecords: CleanWeatherRecord[];
  summary: DatasetSummary;
  validationWarnings: string[];
}

export function preprocessDataset(rawRecords: RawWeatherRecord[]): PreprocessingResult {
  const cleanRecords: CleanWeatherRecord[] = [];
  const warnings: string[] = [];
  const seenRecordKeys = new Set<string>();

  for (let i = 0; i < rawRecords.length; i++) {
    const raw = rawRecords[i];
    const rowNum = i + 1;

    // Validate presence
    if (
      raw.temperature === undefined ||
      raw.previous_temperature === undefined ||
      raw.humidity === undefined ||
      raw.pressure === undefined ||
      raw.wind_speed === undefined ||
      !raw.season
    ) {
      warnings.push(`Row ${rowNum}: Skipped due to missing required fields.`);
      continue;
    }

    const temp = Number(raw.temperature);
    const prevTemp = Number(raw.previous_temperature);
    const humidity = Number(raw.humidity);
    const pressure = Number(raw.pressure);
    const windSpeed = Number(raw.wind_speed);
    const cloudCover = raw.cloud_cover !== undefined ? Number(raw.cloud_cover) : 0;
    const precipitation = raw.precipitation !== undefined ? Number(raw.precipitation) : 0;

    // Range checks
    if (isNaN(temp) || temp < -50 || temp > 60) {
      warnings.push(`Row ${rowNum}: Temperature ${temp}°C outside valid range [-50, 60]. Skipped.`);
      continue;
    }
    if (isNaN(prevTemp) || prevTemp < -50 || prevTemp > 60) {
      warnings.push(`Row ${rowNum}: Previous temperature ${prevTemp}°C outside valid range [-50, 60]. Skipped.`);
      continue;
    }
    if (isNaN(humidity) || humidity < 0 || humidity > 100) {
      warnings.push(`Row ${rowNum}: Humidity ${humidity}% outside valid range [0, 100]. Skipped.`);
      continue;
    }
    if (isNaN(pressure) || pressure < 800 || pressure > 1100) {
      warnings.push(`Row ${rowNum}: Pressure ${pressure} hPa outside valid range [800, 1100]. Skipped.`);
      continue;
    }
    if (isNaN(windSpeed) || windSpeed < 0 || windSpeed > 250) {
      warnings.push(`Row ${rowNum}: Wind speed ${windSpeed} km/h invalid. Skipped.`);
      continue;
    }
    if (isNaN(cloudCover) || cloudCover < 0 || cloudCover > 100) {
      warnings.push(`Row ${rowNum}: Cloud cover ${cloudCover}% outside valid range [0, 100]. Skipped.`);
      continue;
    }
    if (isNaN(precipitation) || precipitation < 0 || precipitation > 500) {
      warnings.push(`Row ${rowNum}: Precipitation ${precipitation} mm invalid. Skipped.`);
      continue;
    }

    // Date and time parsing
    const dateStr = raw.date ? String(raw.date).trim() : '2024-01-01';
    const timeStr = raw.time ? String(raw.time).trim() : '12:00';
    
    // Duplicate detection based on date, time, and record_id
    const dedupKey = `${dateStr}_${timeStr}_${raw.record_id || rowNum}`;
    if (seenRecordKeys.has(dedupKey)) {
      warnings.push(`Row ${rowNum}: Duplicate observation detected for ${dateStr} ${timeStr}. Skipped.`);
      continue;
    }
    seenRecordKeys.add(dedupKey);

    const parsedDate = new Date(dateStr);
    const month = isNaN(parsedDate.getTime()) ? 1 : parsedDate.getMonth() + 1;
    const dayOfWeek = isNaN(parsedDate.getTime()) ? 0 : parsedDate.getDay();

    const timeParts = timeStr.split(':');
    const hour = timeParts.length > 0 && !isNaN(Number(timeParts[0])) ? Math.min(23, Math.max(0, Number(timeParts[0]))) : 12;

    const season = normalizeSeason(raw.season);
    const recordId = raw.record_id ? String(raw.record_id).trim() : `REC-${1000 + rowNum}`;

    cleanRecords.push({
      record_id: recordId,
      date: dateStr,
      time: timeStr,
      temperature: temp,
      previous_temperature: prevTemp,
      humidity,
      pressure,
      wind_speed: windSpeed,
      cloud_cover: cloudCover,
      precipitation,
      season,
      hour,
      month,
      dayOfWeek,
      tempChange: Number((temp - prevTemp).toFixed(2)),
    });
  }

  if (cleanRecords.length === 0) {
    throw new Error('No valid records remained after data preprocessing.');
  }

  // Calculate dynamic dataset summary
  const total = cleanRecords.length;
  const temps = cleanRecords.map((r) => r.temperature).sort((a, b) => a - b);
  const sumTemp = temps.reduce((acc, v) => acc + v, 0);
  const minTemp = temps[0];
  const maxTemp = temps[temps.length - 1];
  const avgTemp = Number((sumTemp / total).toFixed(1));
  const medianTemp = total % 2 === 0 ? (temps[total / 2 - 1] + temps[total / 2]) / 2 : temps[Math.floor(total / 2)];

  const avgHumidity = Number((cleanRecords.reduce((acc, r) => acc + r.humidity, 0) / total).toFixed(1));
  const avgPressure = Number((cleanRecords.reduce((acc, r) => acc + r.pressure, 0) / total).toFixed(1));
  const avgWindSpeed = Number((cleanRecords.reduce((acc, r) => acc + r.wind_speed, 0) / total).toFixed(1));
  const avgPrecipitation = Number((cleanRecords.reduce((acc, r) => acc + r.precipitation, 0) / total).toFixed(2));

  // Season counts
  const seasonCounts: Record<Season, number> = { Spring: 0, Summer: 0, Autumn: 0, Winter: 0 };
  cleanRecords.forEach((r) => {
    seasonCounts[r.season] = (seasonCounts[r.season] || 0) + 1;
  });

  let mostCommonSeason: Season = 'Spring';
  let maxCount = -1;
  SEASONS.forEach((s) => {
    if (seasonCounts[s] > maxCount) {
      maxCount = seasonCounts[s];
      mostCommonSeason = s;
    }
  });

  const dates = cleanRecords.map((r) => r.date).filter(Boolean).sort();
  const dateRange = {
    start: dates.length > 0 ? dates[0] : 'N/A',
    end: dates.length > 0 ? dates[dates.length - 1] : 'N/A',
  };

  const summary: DatasetSummary = {
    totalRecords: rawRecords.length,
    validRecords: cleanRecords.length,
    removedRecords: rawRecords.length - cleanRecords.length,
    avgTemperature: avgTemp,
    medianTemperature: Number(medianTemp.toFixed(1)),
    minTemperature: Number(minTemp.toFixed(1)),
    maxTemperature: Number(maxTemp.toFixed(1)),
    avgHumidity,
    avgPressure,
    avgWindSpeed,
    avgPrecipitation,
    mostCommonSeason,
    dateRange,
  };

  return { cleanRecords, summary, validationWarnings: warnings };
}
