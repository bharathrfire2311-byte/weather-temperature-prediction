import {
  CleanWeatherRecord,
  ModelEvaluation,
  PredictionPoint,
  WeatherPredictionInput,
  PredictionResult,
} from '../types';
import {
  extractFeatureVector,
  extractPredictionFeatureVector,
  fitScaler,
  FEATURE_NAMES,
} from './featureEngineering';
import { trainLinearRegression, LinearRegressionModel } from './linearRegression';
import { trainRandomForest, RandomForestModel } from './randomForest';
import { calculateMetrics, calculateResidualStats } from '../utils/metrics';
import { getTemperatureCategory } from '../utils/weatherAnalysis';

export interface TrainingArtifacts {
  linearModel: LinearRegressionModel;
  rfModel: RandomForestModel;
  linearEvaluation: ModelEvaluation;
  rfEvaluation: ModelEvaluation;
  trainCount: number;
  testCount: number;
  featureNames: string[];
}

export async function trainAndEvaluateModels(
  records: CleanWeatherRecord[],
  onProgress?: (step: string, percentage: number) => void
): Promise<TrainingArtifacts> {
  onProgress?.('Preparing chronological 80/20 train-test split...', 15);

  const featureNamesList = [...FEATURE_NAMES];
  const n = records.length;
  // Chronological 80% train, 20% test
  const splitIndex = Math.floor(n * 0.8);

  const trainRecords = records.slice(0, splitIndex);
  const testRecords = records.slice(splitIndex);

  const X_train = trainRecords.map(extractFeatureVector);
  const y_train = trainRecords.map((r) => r.temperature);

  const X_test = testRecords.map(extractFeatureVector);
  const y_test = testRecords.map((r) => r.temperature);

  onProgress?.('Fitting feature standardizer on training partition...', 30);
  const scaler = fitScaler(X_train);

  onProgress?.('Training Linear Regression model...', 50);
  // Yield to UI loop briefly
  await new Promise((resolve) => setTimeout(resolve, 50));
  const linearModel = trainLinearRegression(X_train, y_train, scaler, featureNamesList);

  onProgress?.('Training Random Forest Regression ensemble...', 70);
  await new Promise((resolve) => setTimeout(resolve, 50));
  const rfModel = trainRandomForest(X_train, y_train, featureNamesList, 15);

  onProgress?.('Evaluating models on test observations...', 90);

  // Evaluate Linear Regression
  const linearPreds = X_test.map((x) => linearModel.predict(x));
  const linearMetrics = calculateMetrics(y_test, linearPreds);
  const linearPoints: PredictionPoint[] = testRecords.map((rec, i) => ({
    recordId: rec.record_id,
    date: `${rec.date} ${rec.time}`,
    actual: rec.temperature,
    predicted: linearPreds[i],
    residual: Number((rec.temperature - linearPreds[i]).toFixed(2)),
  }));
  const linearResidualStats = calculateResidualStats(y_test, linearPreds);

  const linearEvaluation: ModelEvaluation = {
    modelName: 'Linear Regression',
    metrics: linearMetrics,
    testPredictions: linearPoints,
    featureImportance: linearModel.coefficients.map((c) => ({
      feature: c.feature,
      importance: c.influence,
      coefficient: c.coefficient,
    })),
    residualStats: linearResidualStats,
  };

  // Evaluate Random Forest
  const rfPreds = X_test.map((x) => rfModel.predict(x));
  const rfMetrics = calculateMetrics(y_test, rfPreds);
  const rfPoints: PredictionPoint[] = testRecords.map((rec, i) => ({
    recordId: rec.record_id,
    date: `${rec.date} ${rec.time}`,
    actual: rec.temperature,
    predicted: rfPreds[i],
    residual: Number((rec.temperature - rfPreds[i]).toFixed(2)),
  }));
  const rfResidualStats = calculateResidualStats(y_test, rfPreds);

  const rfEvaluation: ModelEvaluation = {
    modelName: 'Random Forest',
    metrics: rfMetrics,
    testPredictions: rfPoints,
    featureImportance: rfModel.featureImportance,
    residualStats: rfResidualStats,
  };

  onProgress?.('Training & validation complete.', 100);

  return {
    linearModel,
    rfModel,
    linearEvaluation,
    rfEvaluation,
    trainCount: trainRecords.length,
    testCount: testRecords.length,
    featureNames: featureNamesList,
  };
}

export function predictTemperature(
  input: WeatherPredictionInput,
  modelType: 'Linear Regression' | 'Random Forest',
  models: any,
  rfEval?: ModelEvaluation | null,
  linearEval?: ModelEvaluation | null
): PredictionResult {
  const featureVector = extractPredictionFeatureVector(input);
  let predicted = 0;

  if (modelType === 'Random Forest' && models?.rfModel) {
    predicted = models.rfModel.predict(featureVector);
  } else if (models?.linearModel) {
    predicted = models.linearModel.predict(featureVector);
  } else {
    // Fallback baseline
    predicted = input.previous_temperature || 20;
  }

  // Round to 1 decimal
  predicted = Number(predicted.toFixed(1));

  // Determine error margin based on active model's RMSE (or default to 1.5)
  const activeEval = modelType === 'Random Forest' ? rfEval : linearEval;
  const rmse = activeEval?.metrics.rmse ?? 1.5;
  const margin = Number((1.96 * (rmse / 2)).toFixed(1));
  const minRange = Number((predicted - margin).toFixed(1));
  const maxRange = Number((predicted + margin).toFixed(1));

  const catInfo = getTemperatureCategory(predicted);

  return {
    predictedTemperature: predicted,
    expectedRange: {
      min: minRange,
      max: maxRange,
      margin,
    },
    category: catInfo.label,
    categoryColor: catInfo.badgeClass,
    inputs: input,
    modelType,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  };
}
