import { CleanWeatherRecord, WeatherPredictionInput } from '../types';
import { encodeSeason } from './encoding';

export const FEATURE_NAMES = [
  'Previous Temperature',
  'Humidity',
  'Atmospheric Pressure',
  'Wind Speed',
  'Cloud Cover',
  'Precipitation',
  'Season: Spring',
  'Season: Summer',
  'Season: Autumn',
  'Season: Winter',
  'Hour of Day',
  'Month',
  'Day of Week',
] as const;

export interface ScalerParams {
  means: number[];
  stds: number[];
}

export function extractFeatureVector(record: CleanWeatherRecord): number[] {
  const [isSpring, isSummer, isAutumn, isWinter] = encodeSeason(record.season);

  return [
    record.previous_temperature,
    record.humidity,
    record.pressure,
    record.wind_speed,
    record.cloud_cover,
    record.precipitation,
    isSpring,
    isSummer,
    isAutumn,
    isWinter,
    record.hour,
    record.month,
    record.dayOfWeek,
  ];
}

export function extractPredictionFeatureVector(input: WeatherPredictionInput, referenceDate?: Date): number[] {
  const [isSpring, isSummer, isAutumn, isWinter] = encodeSeason(input.season);

  let hour = 12;
  if (input.time) {
    const parts = input.time.split(':');
    if (parts.length > 0 && !isNaN(Number(parts[0]))) {
      hour = Number(parts[0]);
    }
  }

  const d = referenceDate || new Date();
  // Map season to representative month if needed
  let month = d.getMonth() + 1;
  if (input.season === 'Spring') month = 4;
  else if (input.season === 'Summer') month = 7;
  else if (input.season === 'Autumn') month = 10;
  else if (input.season === 'Winter') month = 1;

  const dayOfWeek = d.getDay();

  return [
    input.previous_temperature,
    input.humidity,
    input.pressure,
    input.wind_speed,
    input.cloud_cover,
    input.precipitation,
    isSpring,
    isSummer,
    isAutumn,
    isWinter,
    hour,
    month,
    dayOfWeek,
  ];
}

export function fitScaler(X: number[][]): ScalerParams {
  const numFeatures = X[0].length;
  const n = X.length;
  const means: number[] = new Array(numFeatures).fill(0);
  const stds: number[] = new Array(numFeatures).fill(0);

  for (let j = 0; j < numFeatures; j++) {
    let sum = 0;
    for (let i = 0; i < n; i++) {
      sum += X[i][j];
    }
    means[j] = sum / n;

    let varianceSum = 0;
    for (let i = 0; i < n; i++) {
      varianceSum += Math.pow(X[i][j] - means[j], 2);
    }
    const std = Math.sqrt(varianceSum / n);
    // Avoid division by zero for constant features
    stds[j] = std === 0 ? 1 : std;
  }

  return { means, stds };
}

export function transformWithScaler(x: number[], scaler: ScalerParams): number[] {
  return x.map((val, idx) => (val - scaler.means[idx]) / scaler.stds[idx]);
}

export function transformMatrixWithScaler(X: number[][], scaler: ScalerParams): number[][] {
  return X.map((row) => transformWithScaler(row, scaler));
}
