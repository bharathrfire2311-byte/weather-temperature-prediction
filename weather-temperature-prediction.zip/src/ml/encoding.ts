import { Season } from '../types';

export const SEASONS: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];

export function normalizeSeason(rawSeason?: string): Season {
  if (!rawSeason) return 'Spring';
  const clean = rawSeason.trim().toLowerCase();
  if (clean.includes('spr')) return 'Spring';
  if (clean.includes('sum')) return 'Summer';
  if (clean.includes('aut') || clean.includes('fall')) return 'Autumn';
  if (clean.includes('win')) return 'Winter';
  return 'Spring';
}

export function encodeSeason(season: Season): [number, number, number, number] {
  // One-hot encoding: [Spring, Summer, Autumn, Winter]
  return [
    season === 'Spring' ? 1 : 0,
    season === 'Summer' ? 1 : 0,
    season === 'Autumn' ? 1 : 0,
    season === 'Winter' ? 1 : 0,
  ];
}
