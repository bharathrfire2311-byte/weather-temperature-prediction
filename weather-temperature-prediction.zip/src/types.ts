export interface RawWeatherRecord {
  record_id?: string;
  date?: string;
  time?: string;
  temperature?: string | number;
  previous_temperature?: string | number;
  humidity?: string | number;
  pressure?: string | number;
  wind_speed?: string | number;
  cloud_cover?: string | number;
  precipitation?: string | number;
  season?: string;
}

export type Season = 'Spring' | 'Summer' | 'Autumn' | 'Winter';

export interface CleanWeatherRecord {
  record_id: string;
  date: string;
  time: string;
  temperature: number;
  previous_temperature: number;
  humidity: number;
  pressure: number;
  wind_speed: number;
  cloud_cover: number;
  precipitation: number;
  season: Season;
  // parsed components
  hour: number;
  month: number;
  dayOfWeek: number;
  tempChange: number;
}

export interface WeatherFeatureVector {
  previous_temperature: number;
  humidity: number;
  pressure: number;
  wind_speed: number;
  cloud_cover: number;
  precipitation: number;
  season_spring: number;
  season_summer: number;
  season_autumn: number;
  season_winter: number;
  hour: number;
  month: number;
  day_of_week: number;
  temp_change_estimate: number;
}

export interface ModelMetrics {
  mae: number;
  mse: number;
  rmse: number;
  r2: number;
}

export interface PredictionPoint {
  recordId: string;
  date: string;
  actual: number;
  predicted: number;
  residual: number;
}

export interface FeatureImportanceItem {
  feature: string;
  importance: number; // 0 to 1 or relative percentage
  coefficient?: number; // for linear regression
}

export interface ModelEvaluation {
  modelName: 'Linear Regression' | 'Random Forest';
  metrics: ModelMetrics;
  testPredictions: PredictionPoint[];
  featureImportance: FeatureImportanceItem[];
  residualStats: {
    meanResidual: number;
    stdResidual: number;
    positiveCount: number;
    negativeCount: number;
    zeroCount: number;
    minResidual: number;
    maxResidual: number;
    biasAssessment: string;
  };
}

export interface WeatherPredictionInput {
  previous_temperature: number;
  humidity: number;
  pressure: number;
  wind_speed: number;
  cloud_cover: number;
  precipitation: number;
  season: Season;
  time: string;
}

export interface PredictionResult {
  predictedTemperature: number;
  expectedRange: {
    min: number;
    max: number;
    margin: number;
  };
  category: string;
  categoryColor: string;
  inputs: WeatherPredictionInput;
  modelType: 'Linear Regression' | 'Random Forest';
  timestamp: string;
}

export interface DatasetSummary {
  totalRecords: number;
  validRecords: number;
  removedRecords: number;
  avgTemperature: number;
  medianTemperature: number;
  minTemperature: number;
  maxTemperature: number;
  avgHumidity: number;
  avgPressure: number;
  avgWindSpeed: number;
  avgPrecipitation: number;
  mostCommonSeason: Season;
  dateRange: {
    start: string;
    end: string;
  };
}

export interface SeasonalSummary {
  season: Season;
  count: number;
  avgTemp: number;
  minTemp: number;
  maxTemp: number;
  avgHumidity: number;
  avgPressure: number;
  avgWindSpeed: number;
}

export interface WeatherInsight {
  id: string;
  category: 'temperature' | 'climate' | 'correlation' | 'model';
  title: string;
  value?: string;
  description: string;
  iconName?: string;
}

export interface TrainedModels {
  linearModel: any;
  rfModel: any;
  linearEvaluation: ModelEvaluation;
  rfEvaluation: ModelEvaluation;
  trainCount: number;
  testCount: number;
  featureNames?: string[];
}
