import Papa from 'papaparse';
import { RawWeatherRecord } from '../types';

export interface DatasetLoadResult {
  data: RawWeatherRecord[];
  errors: string[];
  totalRowsParsed: number;
}

const REQUIRED_COLUMNS = [
  'temperature',
  'previous_temperature',
  'humidity',
  'pressure',
  'wind_speed',
  'season',
];

export async function fetchWeatherCSV(csvUrl: string = '/data/weather_temperature.csv'): Promise<DatasetLoadResult> {
  const response = await fetch(csvUrl);
  if (!response.ok) {
    throw new Error(`Failed to load weather dataset: HTTP ${response.status} ${response.statusText}`);
  }

  const csvText = await response.text();
  if (!csvText || csvText.trim().length === 0) {
    throw new Error('Dataset file is empty.');
  }

  return new Promise((resolve, reject) => {
    Papa.parse<RawWeatherRecord>(csvText, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header) => header.trim().toLowerCase(),
      complete: (results) => {
        if (!results.data || results.data.length === 0) {
          reject(new Error('No records could be parsed from the CSV file.'));
          return;
        }

        // Validate required columns
        const headers = results.meta.fields || Object.keys(results.data[0] || {});
        const missing = REQUIRED_COLUMNS.filter((col) => !headers.includes(col));

        if (missing.length > 0) {
          reject(new Error(`Dataset is missing required columns: ${missing.join(', ')}`));
          return;
        }

        const parsingErrors = results.errors.map((e) => `Row ${e.row}: ${e.message}`);

        resolve({
          data: results.data,
          errors: parsingErrors,
          totalRowsParsed: results.data.length,
        });
      },
      error: (error) => {
        reject(new Error(`CSV parsing error: ${error.message}`));
      },
    });
  });
}
