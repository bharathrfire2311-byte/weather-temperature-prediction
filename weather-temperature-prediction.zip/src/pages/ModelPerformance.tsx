import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  Award,
  Cpu,
  TrendingDown,
  Zap,
} from 'lucide-react';
import { ModelEvaluation, WeatherInsight } from '../types';
import { StatCard } from '../components/StatCard';
import { ChartCard } from '../components/ChartCard';
import { ModelMetrics } from '../components/ModelMetrics';
import { ResidualChart } from '../components/ResidualChart';

interface ModelPerformanceProps {
  linearEval: ModelEvaluation | null;
  rfEval: ModelEvaluation | null;
  insights: WeatherInsight[];
}

export const ModelPerformance: React.FC<ModelPerformanceProps> = ({
  linearEval,
  rfEval,
  insights,
}) => {
  if (!linearEval || !rfEval) {
    return (
      <div className="p-12 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
        Evaluating machine learning models on chronological test split...
      </div>
    );
  }

  const rfImportance = rfEval.featureImportance || [];
  const linearImportance = linearEval.featureImportance || [];

  return (
    <div id="model-performance-page" className="space-y-8">
      {/* Header Banner */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div className="flex items-center space-x-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-sky-50 text-sky-700 border border-sky-200">
            Regression Diagnostics
          </span>
          <span className="text-xs text-slate-400">Chronological 80% Train / 20% Test</span>
        </div>
        <h2 className="text-lg font-bold text-slate-900 mt-1">
          Machine Learning Model Performance & Evaluation
        </h2>
        <p className="text-xs text-slate-500 mt-0.5 max-w-2xl leading-relaxed">
          Comprehensive benchmark of Linear Regression (L2 Ridge) versus Non-Linear Ensemble Random Forest, tracking MAE, MSE, RMSE, R², residual distributions, and feature importance.
        </p>
      </div>

      {/* Regression Metrics Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard
          id="stat-rf-r2"
          title="Random Forest R²"
          value={String(rfEval.metrics.r2)}
          subtitle="Variance explained (max 1.0)"
          icon={<Award className="w-4 h-4 text-emerald-600" />}
        />
        <StatCard
          id="stat-rf-rmse"
          title="Random Forest RMSE"
          value={`${rfEval.metrics.rmse}°C`}
          subtitle="Standard error of prediction"
          icon={<TrendingDown className="w-4 h-4 text-sky-600" />}
        />
        <StatCard
          id="stat-linear-r2"
          title="Linear Regression R²"
          value={String(linearEval.metrics.r2)}
          subtitle="Linear correlation coefficient"
          icon={<Cpu className="w-4 h-4 text-indigo-600" />}
        />
        <StatCard
          id="stat-linear-rmse"
          title="Linear Regression RMSE"
          value={`${linearEval.metrics.rmse}°C`}
          subtitle="Residual root mean square"
          icon={<TrendingDown className="w-4 h-4 text-slate-600" />}
        />
      </div>

      {/* Side-by-side Comparative Table */}
      <ModelMetrics linearEval={linearEval} rfEval={rfEval} />

      {/* Actual vs Predicted & Residual Distribution Charts */}
      <ResidualChart linearEval={linearEval} rfEval={rfEval} />

      {/* Feature Importance Analysis */}
      <div className="space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            Feature Importance & Parameter Influence
          </h3>
          <p className="text-xs text-slate-500">
            Relative variance reduction (Random Forest) and standardized coefficient impact (Linear Regression)
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ChartCard
            id="rf-feature-importance-chart"
            title="Random Forest Feature Importance"
            subtitle="Normalized percentage of MSE reduction attributed to each split parameter"
            badge="Ensemble Splits"
          >
            <ResponsiveContainer width="100%" height={280}>
              <BarChart
                data={rfImportance}
                layout="vertical"
                margin={{ top: 10, right: 20, bottom: 10, left: 70 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis
                  type="number"
                  unit="%"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                />
                <YAxis
                  type="category"
                  dataKey="feature"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Relative Importance']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '0.75rem',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="importance" fill="#0284c7" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard
            id="linear-feature-influence-chart"
            title="Linear Regression Relative Weights"
            subtitle="Magnitude of normalized regression weights driving positive or negative thermal change"
            badge="Linear Weights"
          >
            <ResponsiveContainer width="100%" height={280}>
              <BarChart
                data={linearImportance}
                layout="vertical"
                margin={{ top: 10, right: 20, bottom: 10, left: 70 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis
                  type="number"
                  unit="%"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                />
                <YAxis
                  type="category"
                  dataKey="feature"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Relative Weight']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '0.75rem',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="importance" fill="#6366f1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>
      </div>

      {/* Architectural Evaluation Conclusions */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center space-x-2">
          <Zap className="w-5 h-5 text-amber-500" />
          <h3 className="text-sm font-bold text-slate-900">
            Architectural Evaluation Conclusions
          </h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="font-semibold text-slate-900 block">Non-Linear Thermal Coupling</span>
            Meteorological processes frequently display threshold behaviors (e.g. cloud shading abruptly capping diurnal peaks). The Random Forest ensemble effectively partitions non-linear boundaries without overfitting.
          </div>
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
            <span className="font-semibold text-slate-900 block">Chronological Integrity</span>
            Evaluating on the final chronological 20% split validates that neither model suffers from forward lookahead leakage, mimicking authentic operational weather forecasting.
          </div>
        </div>
      </div>
    </div>
  );
};
