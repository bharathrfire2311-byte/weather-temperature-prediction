import React from 'react';
import {
  Sparkles,
  Info,
  Thermometer,
  ShieldCheck,
  TrendingUp,
  Cpu,
} from 'lucide-react';
import {
  WeatherPredictionInput,
  PredictionResult,
  ModelEvaluation,
} from '../types';
import { WeatherForm } from '../components/WeatherForm';
import { TemperatureResult } from '../components/TemperatureResult';

interface TemperaturePredictorProps {
  onPredict: (input: WeatherPredictionInput, modelType: 'Linear Regression' | 'Random Forest') => void;
  selectedModel: 'Linear Regression' | 'Random Forest';
  onSelectModel: (model: 'Linear Regression' | 'Random Forest') => void;
  prediction: PredictionResult | null;
  rfEval: ModelEvaluation | null;
  linearEval: ModelEvaluation | null;
  isModelReady: boolean;
}

export const TemperaturePredictor: React.FC<TemperaturePredictorProps> = ({
  onPredict,
  selectedModel,
  onSelectModel,
  prediction,
  rfEval,
  linearEval,
  isModelReady,
}) => {
  const activeEval = selectedModel === 'Random Forest' ? rfEval : linearEval;

  return (
    <div id="temperature-predictor-page" className="space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-sky-50 text-sky-700 border border-sky-200">
              Interactive Inference
            </span>
            <span className="text-xs text-slate-400">Client-side execution</span>
          </div>
          <h2 className="text-lg font-bold text-slate-900 mt-1">
            Weather Temperature Predictor
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 max-w-xl">
            Provide observed meteorological variables or choose standard regional conditions to forecast next ambient temperature in real time.
          </p>
        </div>

        {activeEval && (
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center space-x-3 shrink-0">
            <div className="p-2 rounded-lg bg-sky-100 text-sky-700">
              <Cpu className="w-4 h-4" />
            </div>
            <div className="text-xs">
              <span className="text-slate-500 block">Active Model Accuracy</span>
              <span className="font-bold text-slate-900 font-mono">
                R² = {activeEval.metrics.r2} (RMSE ±{activeEval.metrics.rmse}°C)
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Main Form and Output Layout */}
      <div className="space-y-6">
        <WeatherForm
          onPredict={onPredict}
          selectedModel={selectedModel}
          onSelectModel={onSelectModel}
          isModelReady={isModelReady}
        />

        <TemperatureResult
          prediction={prediction}
          selectedModelName={selectedModel}
        />
      </div>

      {/* Physics and Meteorological Reference Guide */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex items-center space-x-2">
          <Info className="w-4 h-4 text-sky-600" />
          <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
            Predictive Thermodynamics & Feature Dynamics
          </h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-600">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="font-semibold text-slate-800 block mb-1">Thermal Inertia (Previous Temp)</span>
            Ambient surface heat displays strong auto-regressive momentum; previous reading serves as the primary baseline state.
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="font-semibold text-slate-800 block mb-1">Atmospheric Pressure & Adiabatic Flow</span>
            High pressure (above 1013 hPa) promotes air subsidence, cloud suppression, and solar insolation, amplifying temperature.
          </div>
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
            <span className="font-semibold text-slate-800 block mb-1">Humidity & Evaporative Dampening</span>
            Elevated relative moisture combined with cloud cover restricts radiative peaks during daytime while dampening nocturnal cooling.
          </div>
        </div>
      </div>
    </div>
  );
};
