import React from 'react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { CleanWeatherRecord, DatasetSummary } from '../types';
import { ChartCard } from '../components/ChartCard';
import { WeatherTable } from '../components/WeatherTable';
import {
  computeSeasonalSummaries,
  computeTimelineWithMovingAverage,
  computeHumidityRangeBreakdown,
} from '../utils/weatherAnalysis';

interface WeatherAnalysisProps {
  records: CleanWeatherRecord[];
  summary: DatasetSummary | null;
  onSelectRecord: (record: CleanWeatherRecord) => void;
}

export const WeatherAnalysis: React.FC<WeatherAnalysisProps> = ({
  records,
  summary,
  onSelectRecord,
}) => {
  if (!summary || records.length === 0) {
    return (
      <div className="p-12 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
        Loading historical records...
      </div>
    );
  }

  const seasonalSummaries = computeSeasonalSummaries(records);
  const trendData = computeTimelineWithMovingAverage(records, 7);
  const humidityBands = computeHumidityRangeBreakdown(records);

  return (
    <div id="weather-analysis-page" className="space-y-8">
      {/* Header Banner */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div className="flex items-center space-x-2">
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            Historical Meteorology
          </span>
          <span className="text-xs text-slate-400">{records.length} Verified Observations</span>
        </div>
        <h2 className="text-lg font-bold text-slate-900 mt-1">
          Weather Pattern Analysis & Archive Explorer
        </h2>
        <p className="text-xs text-slate-500 mt-0.5 max-w-2xl leading-relaxed">
          Comprehensive exploration of atmospheric observations, seasonal distributions, diurnal oscillations, and inter-variable correlations.
        </p>
      </div>

      {/* Weather Records Explorer Table */}
      <div className="space-y-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            Interactive Historical Weather Records
          </h3>
          <p className="text-xs text-slate-500">
            Search by identifier or date, filter by season, sort columns, and click any entry to view full observations
          </p>
        </div>

        <WeatherTable records={records} onSelectRecord={onSelectRecord} />
      </div>

      {/* Trend Analysis Section */}
      <div className="space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            1. Temperature Trend Analysis (7-Period Moving Average)
          </h3>
          <p className="text-xs text-slate-500">
            Smoothed moving average reveals macro seasonal transitions alongside diurnal swings
          </p>
        </div>

        <ChartCard
          id="chart-temperature-moving-avg"
          title="Observed Temperature vs 7-Period Trend"
          subtitle="Direct observation sequence overlaid with rolling moving average to isolate seasonal waves"
          badge="Trendline"
        >
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={trendData} margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <defs>
                <linearGradient id="trendGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0284c7" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 10, fill: '#64748b' }}
                interval={Math.floor(trendData.length / 6)}
              />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit="°" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: 'none',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Area
                type="monotone"
                dataKey="temperature"
                stroke="#94a3b8"
                strokeWidth={1}
                fill="url(#trendGradient)"
                name="Observed Temp (°C)"
              />
              <Area
                type="monotone"
                dataKey="movingAverage"
                stroke="#0284c7"
                strokeWidth={2.5}
                fill="none"
                name="7-Period Moving Avg (°C)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Seasonal Comparison Cards */}
      <div className="space-y-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            2. Seasonal Microclimate Summaries
          </h3>
          <p className="text-xs text-slate-500">
            Comparative statistics across all four meteorological seasons
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {seasonalSummaries.map((s) => (
            <div
              key={s.season}
              className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3"
            >
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  {s.season}
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                  {s.count} readings
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-baseline">
                  <span className="text-slate-500">Mean Temp:</span>
                  <span className="text-base font-bold text-slate-900 font-mono">{s.avgTemp}°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Range:</span>
                  <span className="font-semibold text-slate-700">{s.minTemp}°C to {s.maxTemp}°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Mean Humidity:</span>
                  <span className="font-semibold text-slate-700">{s.avgHumidity}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Mean Pressure:</span>
                  <span className="font-semibold text-slate-700">{s.avgPressure} hPa</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Mean Wind:</span>
                  <span className="font-semibold text-slate-700">{s.avgWindSpeed} km/h</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Humidity & Atmospheric Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard
          id="chart-humidity-breakdown"
          title="Relative Humidity Level Breakdown"
          subtitle="Observation volume categorized into standard atmospheric moisture bands"
          badge="Atmospheric Moisture"
        >
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={humidityBands} margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="bucket" tick={{ fontSize: 10, fill: '#64748b' }} />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(val: any) => [`${val} records`, 'Count']}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: 'none',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Bar dataKey="count" fill="#38bdf8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          id="chart-pressure-vs-wind"
          title="Pressure vs Wind Velocity Dynamic"
          subtitle="Steep pressure gradients frequently produce higher-velocity surface wind gusts"
          badge="Barometric Coupling"
        >
          <ResponsiveContainer width="100%" height={260}>
            <ScatterChart margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="pressure"
                name="Pressure"
                unit=" hPa"
                domain={['dataMin - 5', 'dataMax + 5']}
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <YAxis
                type="number"
                dataKey="wind_speed"
                name="Wind Speed"
                unit=" km/h"
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: 'none',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Scatter
                name="Readings"
                data={records.filter((_, i) => i % 5 === 0)}
                fill="#6366f1"
                fillOpacity={0.6}
              />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
};
