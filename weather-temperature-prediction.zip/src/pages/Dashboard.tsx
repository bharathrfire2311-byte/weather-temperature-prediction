import React from 'react';
import {
  BarChart,
  Bar,
  AreaChart,
  Area,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import {
  Thermometer,
  Droplets,
  Gauge,
  Wind,
  Database,
  Calendar,
  Sparkles,
  ArrowRight,
  Flame,
  Snowflake,
} from 'lucide-react';
import {
  CleanWeatherRecord,
  DatasetSummary,
  ModelEvaluation,
  WeatherInsight,
} from '../types';
import { StatCard } from '../components/StatCard';
import { ChartCard } from '../components/ChartCard';
import {
  computeTemperatureDistribution,
  computeSeasonalSummaries,
  computeTimelineWithMovingAverage,
} from '../utils/weatherAnalysis';

interface DashboardProps {
  summary: DatasetSummary | null;
  records: CleanWeatherRecord[];
  rfEval: ModelEvaluation | null;
  linearEval: ModelEvaluation | null;
  insights: WeatherInsight[];
  onNavigateToPredictor: () => void;
  onNavigateToAnalysis: () => void;
  onNavigateToPerformance: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  summary,
  records,
  rfEval,
  linearEval,
  insights,
  onNavigateToPredictor,
  onNavigateToAnalysis,
  onNavigateToPerformance,
}) => {
  if (!summary || records.length === 0) {
    return (
      <div className="p-12 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
        Loading meteorological dataset...
      </div>
    );
  }

  const tempDistribution = computeTemperatureDistribution(records);
  const seasonalAverages = computeSeasonalSummaries(records);
  const timelineData = computeTimelineWithMovingAverage(records);

  const sampledStep = Math.max(1, Math.floor(records.length / 100));
  const tempVsHumidity = records
    .filter((_, i) => i % sampledStep === 0)
    .map((r) => ({ x: r.humidity, y: r.temperature, id: r.record_id, season: r.season }));

  const tempVsPressure = records
    .filter((_, i) => i % sampledStep === 0)
    .map((r) => ({ x: r.pressure, y: r.temperature, id: r.record_id, season: r.season }));

  const tempVsWind = records
    .filter((_, i) => i % sampledStep === 0)
    .map((r) => ({ x: r.wind_speed, y: r.temperature, id: r.record_id, season: r.season }));

  return (
    <div id="dashboard-page" className="space-y-6">
      {/* Quick Launch Hero Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-sky-500/20 text-sky-300 border border-sky-400/30">
              Autonomous Machine Learning
            </span>
            <span className="text-xs text-slate-400">80/20 Chronological Split</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-white">
            Meteorological Temperature Prediction Engine
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Estimates ambient surface temperatures using browser-trained Random Forest and Ridge Regression models on historical observations.
          </p>
        </div>

        <button
          type="button"
          onClick={onNavigateToPredictor}
          className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-semibold transition-all shadow-xs active:scale-95 shrink-0"
        >
          <Sparkles className="w-4 h-4" />
          <span>Launch Predictor</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Summary Stat Cards Grid (8 Cards as requested) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard
          id="stat-total-records"
          title="Total Weather Records"
          value={summary.totalRecords.toLocaleString()}
          subtitle="Chronological historical observations"
          icon={<Database className="w-4 h-4 text-sky-600" />}
        />
        <StatCard
          id="stat-avg-temp"
          title="Average Temperature"
          value={`${summary.avgTemperature}°C`}
          subtitle="Mean regional ambient reading"
          icon={<Thermometer className="w-4 h-4 text-amber-500" />}
        />
        <StatCard
          id="stat-min-temp"
          title="Minimum Temperature"
          value={`${summary.minTemperature}°C`}
          subtitle="Recorded seasonal low"
          icon={<Snowflake className="w-4 h-4 text-blue-500" />}
        />
        <StatCard
          id="stat-max-temp"
          title="Maximum Temperature"
          value={`${summary.maxTemperature}°C`}
          subtitle="Recorded seasonal high"
          icon={<Flame className="w-4 h-4 text-rose-500" />}
        />
        <StatCard
          id="stat-avg-humidity"
          title="Average Humidity"
          value={`${summary.avgHumidity}%`}
          subtitle="Mean relative moisture saturation"
          icon={<Droplets className="w-4 h-4 text-sky-500" />}
        />
        <StatCard
          id="stat-avg-pressure"
          title="Average Pressure"
          value={`${summary.avgPressure} hPa`}
          subtitle="Mean sea-level barometric pressure"
          icon={<Gauge className="w-4 h-4 text-indigo-500" />}
        />
        <StatCard
          id="stat-avg-wind"
          title="Average Wind Speed"
          value={`${summary.avgWindSpeed} km/h`}
          subtitle="Mean surface velocity"
          icon={<Wind className="w-4 h-4 text-teal-500" />}
        />
        <StatCard
          id="stat-common-season"
          title="Most Common Season"
          value={summary.mostCommonSeason}
          subtitle="Dominant period in archive"
          icon={<Calendar className="w-4 h-4 text-emerald-500" />}
        />
      </div>

      {/* Primary Visualizations Grid (All 6 core charts) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Temperature Distribution */}
        <ChartCard
          id="chart-temp-distribution"
          title="Temperature Distribution"
          subtitle="Frequency histogram of historical temperature readings across bins"
          badge="Distribution"
        >
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={tempDistribution} margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="range" tick={{ fontSize: 10, fill: '#64748b' }} interval={0} />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
              <Tooltip
                formatter={(val: any) => [`${val} records`, 'Frequency']}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: 'none',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Bar dataKey="count" fill="#0284c7" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 2. Temperature Over Time */}
        <ChartCard
          id="chart-temp-timeline"
          title="Temperature Observations Over Time"
          subtitle="Continuous timeline showing regional diurnal and seasonal thermal waves"
          badge="Timeline"
        >
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={timelineData} margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <defs>
                <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 10, fill: '#64748b' }}
                interval={Math.floor(timelineData.length / 5)}
              />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit="°" />
              <Tooltip
                formatter={(val: any) => [`${val}°C`, 'Temperature']}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: 'none',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Area
                type="monotone"
                dataKey="temperature"
                stroke="#0284c7"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#tempGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 3. Temperature vs Humidity */}
        <ChartCard
          id="chart-temp-vs-humidity"
          title="Temperature vs Humidity"
          subtitle="Inverse atmospheric moisture correlation: warmer air typically displays lower relative humidity"
          badge="Scatter"
        >
          <ResponsiveContainer width="100%" height={260}>
            <ScatterChart margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="x"
                name="Humidity"
                unit="%"
                domain={[0, 100]}
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <YAxis
                type="number"
                dataKey="y"
                name="Temperature"
                unit="°C"
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="p-2.5 bg-slate-900 text-white text-xs rounded-xl shadow-lg border border-slate-800">
                        <div className="font-mono text-sky-400 font-semibold">{data.id}</div>
                        <div>Humidity: <span className="font-bold">{data.x}%</span></div>
                        <div>Temperature: <span className="font-bold">{data.y}°C</span></div>
                        <div className="text-[11px] text-slate-400">Season: {data.season}</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="Observations" data={tempVsHumidity} fill="#0ea5e9" fillOpacity={0.65} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 4. Temperature vs Pressure */}
        <ChartCard
          id="chart-temp-vs-pressure"
          title="Temperature vs Atmospheric Pressure"
          subtitle="Barometric variance across anticyclonic ridges vs cyclonic weather systems"
          badge="Scatter"
        >
          <ResponsiveContainer width="100%" height={260}>
            <ScatterChart margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="x"
                name="Pressure"
                unit=" hPa"
                domain={['dataMin - 5', 'dataMax + 5']}
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <YAxis
                type="number"
                dataKey="y"
                name="Temperature"
                unit="°C"
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="p-2.5 bg-slate-900 text-white text-xs rounded-xl shadow-lg border border-slate-800">
                        <div className="font-mono text-sky-400 font-semibold">{data.id}</div>
                        <div>Pressure: <span className="font-bold">{data.x} hPa</span></div>
                        <div>Temperature: <span className="font-bold">{data.y}°C</span></div>
                        <div className="text-[11px] text-slate-400">Season: {data.season}</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="Observations" data={tempVsPressure} fill="#6366f1" fillOpacity={0.65} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 5. Temperature vs Wind Speed */}
        <ChartCard
          id="chart-temp-vs-wind"
          title="Temperature vs Wind Speed"
          subtitle="Boundary-layer mixing and surface wind dispersal impact on ambient temperatures"
          badge="Scatter"
        >
          <ResponsiveContainer width="100%" height={260}>
            <ScatterChart margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="x"
                name="Wind Speed"
                unit=" km/h"
                domain={[0, 'dataMax + 5']}
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <YAxis
                type="number"
                dataKey="y"
                name="Temperature"
                unit="°C"
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="p-2.5 bg-slate-900 text-white text-xs rounded-xl shadow-lg border border-slate-800">
                        <div className="font-mono text-sky-400 font-semibold">{data.id}</div>
                        <div>Wind Speed: <span className="font-bold">{data.x} km/h</span></div>
                        <div>Temperature: <span className="font-bold">{data.y}°C</span></div>
                        <div className="text-[11px] text-slate-400">Season: {data.season}</div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter name="Observations" data={tempVsWind} fill="#14b8a6" fillOpacity={0.65} />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* 6. Average Temperature by Season */}
        <ChartCard
          id="chart-temp-by-season"
          title="Average Temperature by Season"
          subtitle="Regional seasonal benchmarks demonstrating summer peaks and winter troughs"
          badge="Seasonal Means"
        >
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={seasonalAverages} margin={{ top: 10, right: 10, bottom: 20, left: -10 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="season" tick={{ fontSize: 11, fill: '#64748b' }} />
              <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit="°" />
              <Tooltip
                formatter={(val: any) => [`${val}°C`, 'Mean Temperature']}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: 'none',
                  borderRadius: '0.75rem',
                  color: '#fff',
                  fontSize: '12px',
                }}
              />
              <Bar dataKey="avgTemp" radius={[6, 6, 0, 0]}>
                {seasonalAverages.map((entry) => {
                  let color = '#0284c7';
                  if (entry.season === 'Summer') color = '#f97316';
                  if (entry.season === 'Winter') color = '#38bdf8';
                  if (entry.season === 'Spring') color = '#10b981';
                  if (entry.season === 'Autumn') color = '#f59e0b';
                  return <Cell key={entry.season} fill={color} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Dynamic Meteorological Insights Bar */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-sky-600" />
            <h3 className="text-sm font-semibold text-slate-900">
              Key Meteorological & Model Insights
            </h3>
          </div>
          <button
            type="button"
            onClick={onNavigateToPerformance}
            className="text-xs font-semibold text-sky-600 hover:text-sky-700 flex items-center space-x-1"
          >
            <span>Inspect Model Diagnostics</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {insights.slice(0, 4).map((ins) => (
            <div
              key={ins.id}
              className="p-3.5 rounded-xl bg-slate-50/70 border border-slate-100 flex items-start space-x-3"
            >
              <div className="w-2 h-2 rounded-full bg-sky-500 mt-1.5 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-slate-800">{ins.title}</h4>
                <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{ins.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
