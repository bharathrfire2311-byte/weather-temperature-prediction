import { CleanWeatherRecord, DatasetSummary, ModelEvaluation } from '../types';
import { calculatePearsonCorrelation, computeSeasonalSummaries } from './weatherAnalysis';

export interface DynamicInsightItem {
  id: string;
  category: 'temperature' | 'climate' | 'correlation' | 'model';
  title: string;
  value: string;
  description: string;
  iconName: 'thermometer' | 'droplets' | 'wind' | 'gauge' | 'brain' | 'sparkles';
}

export function generateDynamicInsights(
  records: CleanWeatherRecord[],
  summary: DatasetSummary,
  linearEval?: ModelEvaluation,
  rfEval?: ModelEvaluation
): DynamicInsightItem[] {
  if (records.length === 0) return [];

  const temps = records.map((r) => r.temperature);
  const prevTemps = records.map((r) => r.previous_temperature);
  const humidities = records.map((r) => r.humidity);
  const pressures = records.map((r) => r.pressure);
  const winds = records.map((r) => r.wind_speed);

  // Correlations
  const corrPrevTemp = calculatePearsonCorrelation(prevTemps, temps);
  const corrHumidity = calculatePearsonCorrelation(humidities, temps);
  const corrPressure = calculatePearsonCorrelation(pressures, temps);
  const corrWind = calculatePearsonCorrelation(winds, temps);

  const seasonal = computeSeasonalSummaries(records);
  const validSeasonal = seasonal.filter((s) => s.count > 0);
  const warmestSeason = validSeasonal.reduce((max, s) => (s.avgTemp > max.avgTemp ? s : max), validSeasonal[0]);
  const coldestSeason = validSeasonal.reduce((min, s) => (s.avgTemp < min.avgTemp ? s : min), validSeasonal[0]);

  // Find strongest non-target correlation
  const correlations = [
    { name: 'Previous Temperature', r: corrPrevTemp, absR: Math.abs(corrPrevTemp) },
    { name: 'Humidity', r: corrHumidity, absR: Math.abs(corrHumidity) },
    { name: 'Atmospheric Pressure', r: corrPressure, absR: Math.abs(corrPressure) },
    { name: 'Wind Speed', r: corrWind, absR: Math.abs(corrWind) },
  ].sort((a, b) => b.absR - a.absR);

  const strongestCorr = correlations[0];

  const insights: DynamicInsightItem[] = [
    {
      id: 'ins-thermal-extremes',
      category: 'temperature',
      title: 'Observed Thermal Range',
      value: `${summary.minTemperature}°C to ${summary.maxTemperature}°C`,
      description: `Mean record temperature sits at ${summary.avgTemperature}°C with median ${summary.medianTemperature}°C across ${summary.validRecords} verified chronological samples.`,
      iconName: 'thermometer',
    },
    {
      id: 'ins-seasonal-contrast',
      category: 'climate',
      title: 'Seasonal Thermal Gradient',
      value: `${warmestSeason.season} (${warmestSeason.avgTemp}°C) vs ${coldestSeason.season} (${coldestSeason.avgTemp}°C)`,
      description: `A dynamic temperature spread of ${(warmestSeason.avgTemp - coldestSeason.avgTemp).toFixed(1)}°C exists between the warmest and coldest periods.`,
      iconName: 'sparkles',
    },
    {
      id: 'ins-atmospheric-coupling',
      category: 'correlation',
      title: 'Dominant Meteorological Driver',
      value: `${strongestCorr.name} (r = ${strongestCorr.r > 0 ? '+' : ''}${strongestCorr.r})`,
      description: `Analysis reveals ${strongestCorr.name} exhibits the highest linear coupling coefficient with local ambient temperature in this dataset.`,
      iconName: 'gauge',
    },
    {
      id: 'ins-ambient-humidity-wind',
      category: 'climate',
      title: 'Atmospheric Baseline',
      value: `${summary.avgHumidity}% RH | ${summary.avgPressure} hPa`,
      description: `Atmospheric pressure averages ${summary.avgPressure} hPa with mean wind velocity of ${summary.avgWindSpeed} km/h, illustrating typical temperate barometric dynamics.`,
      iconName: 'droplets',
    },
  ];

  if (linearEval && rfEval) {
    const betterModel = rfEval.metrics.rmse <= linearEval.metrics.rmse ? rfEval : linearEval;
    const topFeature = betterModel.featureImportance[0]?.feature || 'Previous Temperature';
    const topImp = betterModel.featureImportance[0]?.importance || 0;

    insights.push({
      id: 'ins-model-performance',
      category: 'model',
      title: 'Predictive Generalization (Test Set)',
      value: `${betterModel.modelName} (RMSE: ${betterModel.metrics.rmse}°C, R²: ${betterModel.metrics.r2})`,
      description: `The ${betterModel.modelName} model achieved lower test-set variance, explaining ${(betterModel.metrics.r2 * 100).toFixed(1)}% of temperature fluctuations.`,
      iconName: 'brain',
    });

    insights.push({
      id: 'ins-feature-influence',
      category: 'model',
      title: 'Primary Feature Influence',
      value: `${topFeature} (${topImp}%)`,
      description: `${topFeature} emerged as the single most influential predictor during empirical variance reduction testing.`,
      iconName: 'wind',
    });
  }

  return insights;
}

export function generateInsights(
  summary: DatasetSummary,
  linearEval?: ModelEvaluation | null,
  rfEval?: ModelEvaluation | null,
  records?: CleanWeatherRecord[]
): DynamicInsightItem[] {
  if (records && records.length > 0) {
    return generateDynamicInsights(
      records,
      summary,
      linearEval || undefined,
      rfEval || undefined
    );
  }

  const insights: DynamicInsightItem[] = [
    {
      id: 'ins-thermal-extremes',
      category: 'temperature',
      title: 'Observed Thermal Range',
      value: `${summary.minTemperature}°C to ${summary.maxTemperature}°C`,
      description: `Mean record temperature sits at ${summary.avgTemperature}°C with median ${summary.medianTemperature}°C across ${summary.validRecords} verified chronological samples.`,
      iconName: 'thermometer',
    },
    {
      id: 'ins-humidity-coupling',
      category: 'climate',
      title: 'Atmospheric Moisture Coupling',
      value: `Average Humidity ${summary.avgHumidity}%`,
      description: `Higher relative moisture saturation limits sensible heating rates while barometric pressure averages ${summary.avgPressure} hPa.`,
      iconName: 'droplets',
    },
    {
      id: 'ins-wind-dynamics',
      category: 'climate',
      title: 'Boundary-Layer Wind Dynamics',
      value: `Average Wind Speed ${summary.avgWindSpeed} km/h`,
      description: `Regional wind velocity enhances advective thermal mixing between ground surface and ambient air.`,
      iconName: 'wind',
    },
    {
      id: 'ins-seasonal-climate',
      category: 'climate',
      title: 'Dominant Seasonal Period',
      value: summary.mostCommonSeason,
      description: `The dataset features ${summary.mostCommonSeason} as its most prominent period, representing typical temperate climate oscillations.`,
      iconName: 'sparkles',
    },
  ];

  if (linearEval && rfEval) {
    const betterModel = rfEval.metrics.rmse <= linearEval.metrics.rmse ? rfEval : linearEval;
    const topFeature = betterModel.featureImportance?.[0]?.feature || 'Previous Temperature';
    const topImp = betterModel.featureImportance?.[0]?.importance || 0;

    insights.push({
      id: 'ins-model-performance',
      category: 'model',
      title: 'Predictive Generalization (Test Set)',
      value: `${betterModel.modelName} (RMSE: ${betterModel.metrics.rmse}°C, R²: ${betterModel.metrics.r2})`,
      description: `The ${betterModel.modelName} model achieved lower test-set variance, explaining ${(betterModel.metrics.r2 * 100).toFixed(1)}% of temperature fluctuations.`,
      iconName: 'brain',
    });

    insights.push({
      id: 'ins-feature-influence',
      category: 'model',
      title: 'Primary Feature Influence',
      value: `${topFeature} (${topImp}%)`,
      description: `${topFeature} emerged as the single most influential predictor during empirical variance reduction testing.`,
      iconName: 'wind',
    });
  }

  return insights;
}
