import { ModelMetrics } from '../types';

export function calculateMetrics(actuals: number[], predicteds: number[]): ModelMetrics {
  const n = actuals.length;
  if (n === 0) {
    return { mae: 0, mse: 0, rmse: 0, r2: 0 };
  }

  let absErrSum = 0;
  let sqErrSum = 0;
  let actualSum = 0;

  for (let i = 0; i < n; i++) {
    const err = actuals[i] - predicteds[i];
    absErrSum += Math.abs(err);
    sqErrSum += err * err;
    actualSum += actuals[i];
  }

  const mae = absErrSum / n;
  const mse = sqErrSum / n;
  const rmse = Math.sqrt(mse);

  const meanActual = actualSum / n;
  let totalVariance = 0;
  for (let i = 0; i < n; i++) {
    totalVariance += Math.pow(actuals[i] - meanActual, 2);
  }

  const r2 = totalVariance === 0 ? 1 : 1 - sqErrSum / totalVariance;

  return {
    mae: Number(mae.toFixed(3)),
    mse: Number(mse.toFixed(3)),
    rmse: Number(rmse.toFixed(3)),
    r2: Number(r2.toFixed(3)),
  };
}

export function calculateResidualStats(actuals: number[], predicteds: number[]) {
  const residuals = actuals.map((act, i) => Number((act - predicteds[i]).toFixed(3)));
  const n = residuals.length;

  if (n === 0) {
    return {
      meanResidual: 0,
      stdResidual: 0,
      positiveCount: 0,
      negativeCount: 0,
      zeroCount: 0,
      minResidual: 0,
      maxResidual: 0,
      biasAssessment: 'Neutral',
    };
  }

  const sum = residuals.reduce((a, b) => a + b, 0);
  const mean = sum / n;

  const variance = residuals.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / n;
  const std = Math.sqrt(variance);

  let pos = 0;
  let neg = 0;
  let zero = 0;
  let min = residuals[0];
  let max = residuals[0];

  residuals.forEach((r) => {
    if (r > 0.05) pos++;
    else if (r < -0.05) neg++;
    else zero++;
    if (r < min) min = r;
    if (r > max) max = r;
  });

  // Bias assessment:
  // Residual = Actual - Predicted
  // If mean is significantly positive (> 0.25), model is systematically underpredicting.
  // If mean is significantly negative (< -0.25), model is systematically overpredicting.
  let biasAssessment = 'Well-Calibrated (No Significant Bias)';
  if (mean > 0.25) {
    biasAssessment = 'Slight Underprediction Bias (Predicted < Actual)';
  } else if (mean < -0.25) {
    biasAssessment = 'Slight Overprediction Bias (Predicted > Actual)';
  }

  return {
    meanResidual: Number(mean.toFixed(3)),
    stdResidual: Number(std.toFixed(3)),
    positiveCount: pos,
    negativeCount: neg,
    zeroCount: zero,
    minResidual: Number(min.toFixed(2)),
    maxResidual: Number(max.toFixed(2)),
    biasAssessment,
  };
}
