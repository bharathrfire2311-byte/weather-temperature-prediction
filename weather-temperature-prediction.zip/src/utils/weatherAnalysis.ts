import { CleanWeatherRecord, SeasonalSummary, Season } from '../types';
import { SEASONS } from '../ml/encoding';

export interface TempCategory {
  label: string;
  badgeClass: string;
  textClass: string;
  description: string;
}

export function getTemperatureCategory(temp: number): TempCategory {
  if (temp < 5) {
    return {
      label: 'Very Cold',
      badgeClass: 'bg-blue-100 text-blue-800 border-blue-200',
      textClass: 'text-blue-700',
      description: 'Substantially chilly; winter outerwear recommended.',
    };
  }
  if (temp < 14) {
    return {
      label: 'Cold',
      badgeClass: 'bg-cyan-100 text-cyan-800 border-cyan-200',
      textClass: 'text-cyan-700',
      description: 'Cool conditions; layered jacket or sweater required.',
    };
  }
  if (temp < 22) {
    return {
      label: 'Mild',
      badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      textClass: 'text-emerald-700',
      description: 'Pleasant, temperate climate typical of spring and autumn.',
    };
  }
  if (temp < 28) {
    return {
      label: 'Warm',
      badgeClass: 'bg-amber-100 text-amber-800 border-amber-200',
      textClass: 'text-amber-700',
      description: 'Comfortably warm; ideal for outdoor activities.',
    };
  }
  return {
    label: 'Hot',
    badgeClass: 'bg-rose-100 text-rose-800 border-rose-200',
    textClass: 'text-rose-700',
    description: 'High thermal index; hydration and sun protection recommended.',
  };
}

export function computeSeasonalSummaries(records: CleanWeatherRecord[]): SeasonalSummary[] {
  return SEASONS.map((season) => {
    const subset = records.filter((r) => r.season === season);
    if (subset.length === 0) {
      return {
        season,
        count: 0,
        avgTemp: 0,
        minTemp: 0,
        maxTemp: 0,
        avgHumidity: 0,
        avgPressure: 0,
        avgWindSpeed: 0,
      };
    }

    const count = subset.length;
    const temps = subset.map((r) => r.temperature);
    const avgTemp = Number((temps.reduce((a, b) => a + b, 0) / count).toFixed(1));
    const minTemp = Math.min(...temps);
    const maxTemp = Math.max(...temps);
    const avgHumidity = Number((subset.reduce((a, b) => a + b.humidity, 0) / count).toFixed(1));
    const avgPressure = Number((subset.reduce((a, b) => a + b.pressure, 0) / count).toFixed(1));
    const avgWindSpeed = Number((subset.reduce((a, b) => a + b.wind_speed, 0) / count).toFixed(1));

    return {
      season,
      count,
      avgTemp,
      minTemp,
      maxTemp,
      avgHumidity,
      avgPressure,
      avgWindSpeed,
    };
  });
}

export function computeTemperatureDistribution(records: CleanWeatherRecord[], binSize = 3) {
  if (records.length === 0) return [];
  const temps = records.map((r) => r.temperature);
  const min = Math.floor(Math.min(...temps) / binSize) * binSize;
  const max = Math.ceil(Math.max(...temps) / binSize) * binSize;

  const bins: { range: string; count: number; min: number; max: number }[] = [];
  for (let b = min; b < max; b += binSize) {
    const rangeLabel = `${b}°C to ${b + binSize}°C`;
    const count = records.filter((r) => r.temperature >= b && r.temperature < b + binSize).length;
    bins.push({ range: rangeLabel, count, min: b, max: b + binSize });
  }

  return bins;
}

export function computeTimelineWithMovingAverage(records: CleanWeatherRecord[], windowSize = 7) {
  return records.map((rec, idx) => {
    const start = Math.max(0, idx - Math.floor(windowSize / 2));
    const end = Math.min(records.length, idx + Math.ceil(windowSize / 2));
    const window = records.slice(start, end);
    const movingAvg = Number((window.reduce((acc, r) => acc + r.temperature, 0) / window.length).toFixed(1));

    return {
      date: rec.date,
      time: rec.time,
      displayDate: `${rec.date} ${rec.time}`,
      temperature: rec.temperature,
      movingAverage: movingAvg,
      humidity: rec.humidity,
      pressure: rec.pressure,
      wind_speed: rec.wind_speed,
      season: rec.season,
    };
  });
}

export function computeHumidityRangeBreakdown(records: CleanWeatherRecord[]) {
  const buckets = [
    { label: 'Dry (< 40%)', min: 0, max: 40 },
    { label: 'Moderate (40 - 65%)', min: 40, max: 65 },
    { label: 'Humid (65 - 80%)', min: 65, max: 80 },
    { label: 'Very High (≥ 80%)', min: 80, max: 101 },
  ];

  return buckets.map((b) => {
    const subset = records.filter((r) => r.humidity >= b.min && r.humidity < b.max);
    const count = subset.length;
    const avgTemp = count > 0 ? Number((subset.reduce((a, b) => a + b.temperature, 0) / count).toFixed(1)) : 0;
    return {
      bucket: b.label,
      count,
      avgTemperature: avgTemp,
    };
  });
}

export function computeWindRangeBreakdown(records: CleanWeatherRecord[]) {
  const buckets = [
    { label: 'Light (< 10 km/h)', min: 0, max: 10 },
    { label: 'Moderate (10 - 20 km/h)', min: 10, max: 20 },
    { label: 'Breezy (20 - 30 km/h)', min: 20, max: 30 },
    { label: 'Strong (≥ 30 km/h)', min: 30, max: 200 },
  ];

  return buckets.map((b) => {
    const subset = records.filter((r) => r.wind_speed >= b.min && r.wind_speed < b.max);
    const count = subset.length;
    const avgTemp = count > 0 ? Number((subset.reduce((a, b) => a + b.temperature, 0) / count).toFixed(1)) : 0;
    return {
      bucket: b.label,
      count,
      avgTemperature: avgTemp,
    };
  });
}

export function calculatePearsonCorrelation(x: number[], y: number[]): number {
  const n = x.length;
  if (n === 0) return 0;
  const avgX = x.reduce((a, b) => a + b, 0) / n;
  const avgY = y.reduce((a, b) => a + b, 0) / n;

  let num = 0;
  let denX = 0;
  let denY = 0;

  for (let i = 0; i < n; i++) {
    const dx = x[i] - avgX;
    const dy = y[i] - avgY;
    num += dx * dy;
    denX += dx * dx;
    denY += dy * dy;
  }

  const den = Math.sqrt(denX * denY);
  return den === 0 ? 0 : Number((num / den).toFixed(3));
}
