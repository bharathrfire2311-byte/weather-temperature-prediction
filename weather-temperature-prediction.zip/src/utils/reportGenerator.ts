import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { DatasetSummary, ModelEvaluation, PredictionResult } from '../types';
import { DynamicInsightItem } from './insights';

export interface ReportDataPayload {
  datasetSummary: DatasetSummary;
  prediction?: PredictionResult | null;
  linearEval?: ModelEvaluation | null;
  rfEval?: ModelEvaluation | null;
  selectedModelName: 'Linear Regression' | 'Random Forest';
  insights: DynamicInsightItem[];
  containerElementToCapture?: HTMLElement | null;
}

export async function generateWeatherPredictionPDF(payload: ReportDataPayload): Promise<void> {
  const { datasetSummary, prediction, linearEval, rfEval, selectedModelName, insights, containerElementToCapture } = payload;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 16;
  let yPos = 20;

  // Header Banner
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Weather Temperature Prediction Report', margin, 13);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(203, 213, 225); // slate-300
  const today = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  doc.text(`Generated: ${today} | Dataset: weather_temperature.csv | Unit: Celsius (°C) | Model: ${selectedModelName}`, margin, 21);

  yPos = 38;

  // Section: Dataset Overview
  doc.setTextColor(15, 23, 42); // slate-900
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('1. Historical Dataset Summary', margin, yPos);
  yPos += 6;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);

  const colWidth = (pageWidth - margin * 2) / 4;
  const rowHeight = 12;

  // Draw Stat Grid
  const stats = [
    { label: 'Total Records', val: `${datasetSummary.validRecords}` },
    { label: 'Avg Temperature', val: `${datasetSummary.avgTemperature}°C` },
    { label: 'Min Temperature', val: `${datasetSummary.minTemperature}°C` },
    { label: 'Max Temperature', val: `${datasetSummary.maxTemperature}°C` },
    { label: 'Avg Humidity', val: `${datasetSummary.avgHumidity}%` },
    { label: 'Avg Pressure', val: `${datasetSummary.avgPressure} hPa` },
    { label: 'Avg Wind Speed', val: `${datasetSummary.avgWindSpeed} km/h` },
    { label: 'Most Common Season', val: `${datasetSummary.mostCommonSeason}` },
  ];

  for (let i = 0; i < stats.length; i++) {
    const col = i % 4;
    const row = Math.floor(i / 4);
    const boxX = margin + col * colWidth;
    const boxY = yPos + row * (rowHeight + 2);

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(boxX, boxY, colWidth - 2, rowHeight, 1.5, 1.5, 'FD');

    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text(stats[i].label, boxX + 3, boxY + 4);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(stats[i].val, boxX + 3, boxY + 9.5);
  }

  yPos += 2 * (rowHeight + 2) + 8;

  // Section: Prediction Result (if available)
  if (prediction) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('2. Temperature Prediction & Weather Inputs', margin, yPos);
    yPos += 6;

    // Highlight card
    doc.setFillColor(238, 242, 255); // indigo-50
    doc.setDrawColor(199, 210, 254);
    doc.roundedRect(margin, yPos, pageWidth - margin * 2, 22, 2, 2, 'FD');

    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(67, 56, 202);
    doc.text(`PREDICTED TEMPERATURE: ${prediction.predictedTemperature}°C`, margin + 5, yPos + 7);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);
    doc.text(
      `Expected Error Range: ${prediction.expectedRange.min}°C – ${prediction.expectedRange.max}°C (±${prediction.expectedRange.margin}°C Test RMSE Error Margin)`,
      margin + 5,
      yPos + 13
    );

    doc.text(
      `Classification: ${prediction.category}  |  Algorithm Used: ${prediction.modelType}`,
      margin + 5,
      yPos + 18
    );

    yPos += 26;

    // Conditions Table
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    const inputsText = `Input Conditions: Prev Temp: ${prediction.inputs.previous_temperature}°C | Humidity: ${prediction.inputs.humidity}% | Pressure: ${prediction.inputs.pressure} hPa | Wind: ${prediction.inputs.wind_speed} km/h | Cloud: ${prediction.inputs.cloud_cover}% | Season: ${prediction.inputs.season} | Time: ${prediction.inputs.time || '12:00'}`;
    doc.text(inputsText, margin, yPos);
    yPos += 8;
  }

  // Section: Model Performance Comparison
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('3. Regression Model Performance (Test Partition)', margin, yPos);
  yPos += 6;

  // Table header
  const tableX = margin;
  const colW1 = 55;
  const colW2 = 60;
  const colW3 = 60;

  doc.setFillColor(241, 245, 249);
  doc.rect(tableX, yPos, colW1 + colW2 + colW3, 7, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(51, 65, 85);
  doc.text('Evaluation Metric', tableX + 3, yPos + 5);
  doc.text('Linear Regression', tableX + colW1 + 3, yPos + 5);
  doc.text('Random Forest', tableX + colW1 + colW2 + 3, yPos + 5);
  yPos += 7;

  const metricRows = [
    { name: 'MAE (Mean Absolute Error) [Lower is better]', l: linearEval?.metrics.mae, rf: rfEval?.metrics.mae },
    { name: 'MSE (Mean Squared Error) [Lower is better]', l: linearEval?.metrics.mse, rf: rfEval?.metrics.mse },
    { name: 'RMSE (Root Mean Squared Error) [Lower is better]', l: linearEval?.metrics.rmse, rf: rfEval?.metrics.rmse },
    { name: 'R² (Coefficient of Determination) [Higher is better]', l: linearEval?.metrics.r2, rf: rfEval?.metrics.r2 },
  ];

  metricRows.forEach((r, idx) => {
    if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(tableX, yPos, colW1 + colW2 + colW3, 6, 'F');
    }
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text(r.name, tableX + 3, yPos + 4.5);
    doc.text(r.l !== undefined ? `${r.l}` : 'N/A', tableX + colW1 + 3, yPos + 4.5);
    doc.text(r.rf !== undefined ? `${r.rf}` : 'N/A', tableX + colW1 + colW2 + 3, yPos + 4.5);
    yPos += 6;
  });

  yPos += 8;

  // Section: Dynamic Weather Insights
  if (insights.length > 0) {
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text('4. Meteorological Findings & Empirical Insights', margin, yPos);
    yPos += 6;

    insights.slice(0, 5).forEach((ins) => {
      if (yPos > 270) {
        doc.addPage();
        yPos = 20;
      }
      doc.setFontSize(8.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text(`• ${ins.title}: `, margin, yPos);

      const titleWidth = doc.getTextWidth(`• ${ins.title}: `);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text(ins.value, margin + titleWidth, yPos);
      yPos += 4.5;

      doc.setFontSize(7.5);
      doc.setTextColor(71, 85, 105);
      const splitDesc = doc.splitTextToSize(ins.description, pageWidth - margin * 2 - 4);
      doc.text(splitDesc, margin + 4, yPos);
      yPos += splitDesc.length * 3.8 + 2;
    });
  }

  // If a chart container element was provided, capture and embed it
  if (containerElementToCapture) {
    try {
      const canvas = await html2canvas(containerElementToCapture, {
        scale: 1.5,
        useCORS: true,
        logging: false,
      });
      const imgData = canvas.toDataURL('image/png');
      doc.addPage();
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(15, 23, 42);
      doc.text('Visual Weather & Model Analytics Capture', margin, 18);

      const imgWidth = pageWidth - margin * 2;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      doc.addImage(imgData, 'PNG', margin, 24, imgWidth, Math.min(imgHeight, 245));
    } catch (err) {
      console.warn('Chart capture skipped in PDF:', err);
    }
  }

  // Footer on all pages
  const totalPages = doc.internal.pages.length - 1;
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184);
    doc.text(`Weather Temperature Prediction System — Page ${p} of ${totalPages}`, margin, 290);
    doc.text('Confidential & Generated Client-Side', pageWidth - margin - 50, 290);
  }

  doc.save('weather-temperature-prediction-report.pdf');
}
