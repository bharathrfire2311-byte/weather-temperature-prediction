import React from 'react';
import {
  Thermometer,
  Gauge,
  Droplets,
  Wind,
  Calendar,
  CloudSun,
  ShieldCheck,
  Info,
  Clock,
  Sparkles,
} from 'lucide-react';
import { PredictionResult } from '../types';
import { getTemperatureCategory } from '../utils/weatherAnalysis';

interface TemperatureResultProps {
  prediction: PredictionResult | null;
  selectedModelName: 'Linear Regression' | 'Random Forest';
}

export const TemperatureResult: React.FC<TemperatureResultProps> = ({
  prediction,
  selectedModelName,
}) => {
  if (!prediction) {
    return (
      <div
        id="empty-prediction-state"
        className="p-8 sm:p-12 rounded-2xl bg-white border border-slate-200/80 shadow-xs text-center flex flex-col items-center justify-center min-h-[300px]"
      >
        <div className="w-16 h-16 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center mb-4">
          <Thermometer className="w-8 h-8" />
        </div>
        <h2 className="text-base font-semibold text-slate-800">No Temperature Prediction Yet</h2>
        <p className="text-xs text-slate-500 max-w-sm mt-1">
          Adjust the weather parameters or pick a preset scenario, then click &ldquo;Predict Temperature&rdquo; to execute browser machine learning inference.
        </p>
      </div>
    );
  }

  const category = getTemperatureCategory(prediction.predictedTemperature);
  const diffFromPrev = Number((prediction.predictedTemperature - prediction.inputs.previous_temperature).toFixed(1));

  return (
    <div
      id="temperature-prediction-result-card"
      className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden"
    >
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 p-6 text-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-semibold tracking-wider uppercase text-sky-400">
                Model Inference Output
              </span>
              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[11px] text-slate-300 border border-slate-700">
                {prediction.modelType}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Estimated based on chronological 80/20 test-partition regression patterns
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <span
              className={`px-3 py-1 rounded-full text-xs font-semibold border ${category.badgeClass}`}
            >
              {category.label}
            </span>
          </div>
        </div>

        {/* Big Temperature Hero Section */}
        <div className="mt-6 flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-4 pb-2">
          <div>
            <span className="text-xs text-slate-400 uppercase tracking-wider block font-medium">
              Predicted Temperature
            </span>
            <div className="flex items-baseline space-x-2 mt-1">
              <span
                id="predicted-temperature-value"
                className="text-5xl sm:text-6xl font-extrabold tracking-tight text-white"
              >
                {prediction.predictedTemperature > 0 ? `+${prediction.predictedTemperature}` : prediction.predictedTemperature}°C
              </span>
              <span className="text-xs font-medium text-slate-400">
                ({diffFromPrev >= 0 ? `+${diffFromPrev}` : `${diffFromPrev}`}°C vs Previous)
              </span>
            </div>
          </div>

          {/* Expected Range Box */}
          <div
            id="expected-temperature-range"
            className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/60 max-w-xs"
          >
            <div className="flex items-center space-x-1.5 text-xs font-medium text-sky-300">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Expected Range (Empirical Test Error)</span>
            </div>
            <div className="text-lg font-bold text-white mt-1">
              {prediction.expectedRange.min}°C – {prediction.expectedRange.max}°C
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Calculated dynamically via test-set RMSE (±{prediction.expectedRange.margin}°C margin)
            </p>
          </div>
        </div>
      </div>

      {/* Meteorological Interpretation */}
      <div className="p-6 border-b border-slate-100 bg-slate-50/60">
        <div className="flex items-start space-x-3">
          <div className="p-2 rounded-xl bg-sky-100 text-sky-700 shrink-0 mt-0.5">
            <Info className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
              Temperature Interpretation ({category.label})
            </h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              {category.description} Ambient readings in this range typically align with{' '}
              <span className="font-semibold text-slate-800">{prediction.inputs.season}</span>{' '}
              atmospheric conditions in the regional historical archive.
            </p>
          </div>
        </div>
      </div>

      {/* Input Condition Summary Chips */}
      <div className="p-6">
        <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
          Applied Environmental Inputs
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <div className="flex items-center space-x-1.5 text-xs text-slate-500">
              <Thermometer className="w-3.5 h-3.5 text-rose-500" />
              <span>Prev Temp</span>
            </div>
            <div className="text-sm font-bold text-slate-800 mt-1">
              {prediction.inputs.previous_temperature}°C
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <div className="flex items-center space-x-1.5 text-xs text-slate-500">
              <Droplets className="w-3.5 h-3.5 text-sky-500" />
              <span>Humidity</span>
            </div>
            <div className="text-sm font-bold text-slate-800 mt-1">
              {prediction.inputs.humidity}%
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <div className="flex items-center space-x-1.5 text-xs text-slate-500">
              <Gauge className="w-3.5 h-3.5 text-indigo-500" />
              <span>Pressure</span>
            </div>
            <div className="text-sm font-bold text-slate-800 mt-1 truncate">
              {prediction.inputs.pressure} hPa
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <div className="flex items-center space-x-1.5 text-xs text-slate-500">
              <Wind className="w-3.5 h-3.5 text-teal-500" />
              <span>Wind</span>
            </div>
            <div className="text-sm font-bold text-slate-800 mt-1">
              {prediction.inputs.wind_speed} km/h
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <div className="flex items-center space-x-1.5 text-xs text-slate-500">
              <CloudSun className="w-3.5 h-3.5 text-amber-500" />
              <span>Cloud Cover</span>
            </div>
            <div className="text-sm font-bold text-slate-800 mt-1">
              {prediction.inputs.cloud_cover}%
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <div className="flex items-center space-x-1.5 text-xs text-slate-500">
              <Calendar className="w-3.5 h-3.5 text-emerald-500" />
              <span>Season</span>
            </div>
            <div className="text-sm font-bold text-slate-800 mt-1">
              {prediction.inputs.season}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <div className="flex items-center space-x-1.5 text-xs text-slate-500">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>Obs. Time</span>
            </div>
            <div className="text-sm font-bold text-slate-800 mt-1">
              {prediction.inputs.time || '12:00'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
