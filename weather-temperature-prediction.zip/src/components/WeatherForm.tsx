import React, { useState } from 'react';
import {
  Sparkles,
  Thermometer,
  Droplets,
  Gauge,
  Wind,
  Cloud,
  CloudRain,
  Calendar,
  Clock,
  RotateCcw,
  SlidersHorizontal,
} from 'lucide-react';
import { Season, WeatherPredictionInput } from '../types';

interface WeatherFormProps {
  onPredict: (input: WeatherPredictionInput, modelType: 'Linear Regression' | 'Random Forest') => void;
  selectedModel: 'Linear Regression' | 'Random Forest';
  onSelectModel: (model: 'Linear Regression' | 'Random Forest') => void;
  isModelReady: boolean;
  defaultSeason?: Season;
}

const PRESET_SCENARIOS: {
  label: string;
  data: WeatherPredictionInput;
  model: 'Linear Regression' | 'Random Forest';
}[] = [
  {
    label: 'Warm Summer Afternoon',
    model: 'Random Forest',
    data: {
      previous_temperature: 26.5,
      humidity: 42,
      pressure: 1012.5,
      wind_speed: 14.0,
      cloud_cover: 25,
      precipitation: 0.0,
      season: 'Summer',
      time: '14:00',
    },
  },
  {
    label: 'Chilly Winter Dawn',
    model: 'Linear Regression',
    data: {
      previous_temperature: 1.8,
      humidity: 88,
      pressure: 1024.0,
      wind_speed: 9.5,
      cloud_cover: 45,
      precipitation: 0.0,
      season: 'Winter',
      time: '06:00',
    },
  },
  {
    label: 'Rainy Autumn Evening',
    model: 'Random Forest',
    data: {
      previous_temperature: 13.2,
      humidity: 92,
      pressure: 998.4,
      wind_speed: 28.0,
      cloud_cover: 95,
      precipitation: 6.8,
      season: 'Autumn',
      time: '20:00',
    },
  },
  {
    label: 'Mild Spring Midday',
    model: 'Linear Regression',
    data: {
      previous_temperature: 16.0,
      humidity: 55,
      pressure: 1016.0,
      wind_speed: 12.0,
      cloud_cover: 30,
      precipitation: 0.0,
      season: 'Spring',
      time: '14:00',
    },
  },
];

export const WeatherForm: React.FC<WeatherFormProps> = ({
  onPredict,
  selectedModel,
  onSelectModel,
  isModelReady,
  defaultSeason = 'Summer',
}) => {
  const [formData, setFormData] = useState<WeatherPredictionInput>({
    previous_temperature: 22.0,
    humidity: 55,
    pressure: 1013.2,
    wind_speed: 15.0,
    cloud_cover: 40,
    precipitation: 0.0,
    season: defaultSeason,
    time: '14:00',
  });

  const [validationError, setValidationError] = useState<string | null>(null);

  const handleChange = (field: keyof WeatherPredictionInput, value: string | number) => {
    setFormData((prev) => ({
      ...prev,
      [field]: typeof prev[field] === 'number' ? Number(value) : value,
    }));
  };

  const handlePresetSelect = (preset: (typeof PRESET_SCENARIOS)[0]) => {
    setFormData(preset.data);
    onSelectModel(preset.model);
    setValidationError(null);
  };

  const handleReset = () => {
    setFormData({
      previous_temperature: 20.0,
      humidity: 50,
      pressure: 1013.0,
      wind_speed: 12.0,
      cloud_cover: 30,
      precipitation: 0.0,
      season: 'Spring',
      time: '12:00',
    });
    setValidationError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    // Form validation
    if (isNaN(formData.previous_temperature) || formData.previous_temperature < -50 || formData.previous_temperature > 60) {
      setValidationError('Previous temperature must be between -50°C and 60°C.');
      return;
    }
    if (isNaN(formData.humidity) || formData.humidity < 0 || formData.humidity > 100) {
      setValidationError('Humidity must be between 0% and 100%.');
      return;
    }
    if (isNaN(formData.pressure) || formData.pressure < 800 || formData.pressure > 1100) {
      setValidationError('Atmospheric pressure must be between 800 hPa and 1100 hPa.');
      return;
    }
    if (isNaN(formData.wind_speed) || formData.wind_speed < 0) {
      setValidationError('Wind speed must be greater than or equal to 0 km/h.');
      return;
    }
    if (isNaN(formData.cloud_cover) || formData.cloud_cover < 0 || formData.cloud_cover > 100) {
      setValidationError('Cloud cover must be between 0% and 100%.');
      return;
    }
    if (isNaN(formData.precipitation) || formData.precipitation < 0) {
      setValidationError('Precipitation must be greater than or equal to 0 mm.');
      return;
    }

    onPredict(formData, selectedModel);
  };

  return (
    <div
      id="weather-prediction-form-card"
      className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-6"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-base font-semibold text-slate-900 tracking-tight flex items-center space-x-2">
            <SlidersHorizontal className="w-5 h-5 text-sky-600" />
            <span>Weather Condition Inputs</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure observed meteorological parameters to estimate next ambient temperature
          </p>
        </div>

        {/* Model Selector Tabs */}
        <div className="flex items-center p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            id="model-select-linear-btn"
            onClick={() => onSelectModel('Linear Regression')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              selectedModel === 'Linear Regression'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Linear Regression
          </button>
          <button
            type="button"
            id="model-select-rf-btn"
            onClick={() => onSelectModel('Random Forest')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              selectedModel === 'Random Forest'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Random Forest
          </button>
        </div>
      </div>

      {/* Preset Scenarios */}
      <div className="space-y-1.5">
        <label className="text-[11px] font-medium uppercase tracking-wider text-slate-400">
          Quick Preset Weather Scenarios
        </label>
        <div className="flex flex-wrap gap-2">
          {PRESET_SCENARIOS.map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => handlePresetSelect(preset)}
              className="px-3 py-1.5 rounded-lg text-xs bg-slate-50 hover:bg-sky-50 hover:text-sky-700 hover:border-sky-200 border border-slate-200/80 text-slate-700 transition-colors"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Previous Temperature */}
          <div className="space-y-1.5">
            <label
              htmlFor="input-prev-temp"
              className="text-xs font-medium text-slate-700 flex items-center space-x-1"
            >
              <Thermometer className="w-3.5 h-3.5 text-rose-500" />
              <span>Previous Temperature (°C)</span>
            </label>
            <input
              id="input-prev-temp"
              type="number"
              step="0.1"
              required
              value={formData.previous_temperature}
              onChange={(e) => handleChange('previous_temperature', e.target.value)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
              placeholder="e.g. 21.5"
            />
          </div>

          {/* Humidity */}
          <div className="space-y-1.5">
            <label
              htmlFor="input-humidity"
              className="text-xs font-medium text-slate-700 flex items-center space-x-1"
            >
              <Droplets className="w-3.5 h-3.5 text-sky-500" />
              <span>Relative Humidity (%)</span>
            </label>
            <input
              id="input-humidity"
              type="number"
              min="0"
              max="100"
              step="1"
              required
              value={formData.humidity}
              onChange={(e) => handleChange('humidity', e.target.value)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
              placeholder="0–100"
            />
          </div>

          {/* Atmospheric Pressure */}
          <div className="space-y-1.5">
            <label
              htmlFor="input-pressure"
              className="text-xs font-medium text-slate-700 flex items-center space-x-1"
            >
              <Gauge className="w-3.5 h-3.5 text-indigo-500" />
              <span>Pressure (hPa)</span>
            </label>
            <input
              id="input-pressure"
              type="number"
              min="800"
              max="1100"
              step="0.1"
              required
              value={formData.pressure}
              onChange={(e) => handleChange('pressure', e.target.value)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
              placeholder="800–1100"
            />
          </div>

          {/* Wind Speed */}
          <div className="space-y-1.5">
            <label
              htmlFor="input-wind-speed"
              className="text-xs font-medium text-slate-700 flex items-center space-x-1"
            >
              <Wind className="w-3.5 h-3.5 text-teal-500" />
              <span>Wind Speed (km/h)</span>
            </label>
            <input
              id="input-wind-speed"
              type="number"
              min="0"
              step="0.5"
              required
              value={formData.wind_speed}
              onChange={(e) => handleChange('wind_speed', e.target.value)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
              placeholder=">= 0"
            />
          </div>

          {/* Cloud Cover */}
          <div className="space-y-1.5">
            <label
              htmlFor="input-cloud-cover"
              className="text-xs font-medium text-slate-700 flex items-center space-x-1"
            >
              <Cloud className="w-3.5 h-3.5 text-slate-500" />
              <span>Cloud Cover (%)</span>
            </label>
            <input
              id="input-cloud-cover"
              type="number"
              min="0"
              max="100"
              step="1"
              required
              value={formData.cloud_cover}
              onChange={(e) => handleChange('cloud_cover', e.target.value)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
              placeholder="0–100"
            />
          </div>

          {/* Precipitation */}
          <div className="space-y-1.5">
            <label
              htmlFor="input-precipitation"
              className="text-xs font-medium text-slate-700 flex items-center space-x-1"
            >
              <CloudRain className="w-3.5 h-3.5 text-blue-500" />
              <span>Precipitation (mm)</span>
            </label>
            <input
              id="input-precipitation"
              type="number"
              min="0"
              step="0.1"
              required
              value={formData.precipitation}
              onChange={(e) => handleChange('precipitation', e.target.value)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
              placeholder=">= 0"
            />
          </div>

          {/* Season */}
          <div className="space-y-1.5">
            <label
              htmlFor="input-season"
              className="text-xs font-medium text-slate-700 flex items-center space-x-1"
            >
              <Calendar className="w-3.5 h-3.5 text-emerald-500" />
              <span>Season</span>
            </label>
            <select
              id="input-season"
              value={formData.season}
              onChange={(e) => handleChange('season', e.target.value as Season)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
            >
              <option value="Spring">Spring</option>
              <option value="Summer">Summer</option>
              <option value="Autumn">Autumn</option>
              <option value="Winter">Winter</option>
            </select>
          </div>

          {/* Time */}
          <div className="space-y-1.5">
            <label
              htmlFor="input-time"
              className="text-xs font-medium text-slate-700 flex items-center space-x-1"
            >
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              <span>Time of Day (Optional)</span>
            </label>
            <input
              id="input-time"
              type="time"
              value={formData.time}
              onChange={(e) => handleChange('time', e.target.value)}
              className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
            />
          </div>
        </div>

        {validationError && (
          <div
            id="form-validation-alert"
            className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium"
          >
            {validationError}
          </div>
        )}

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <button
            type="button"
            id="reset-form-btn"
            onClick={handleReset}
            className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-medium transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Values</span>
          </button>

          <button
            type="submit"
            id="predict-temperature-btn"
            disabled={!isModelReady}
            className={`w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-all shadow-sm ${
              isModelReady
                ? 'bg-sky-600 hover:bg-sky-500 text-white active:scale-[0.98]'
                : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4 text-sky-200" />
            <span>Predict Temperature</span>
          </button>
        </div>
      </form>
    </div>
  );
};
