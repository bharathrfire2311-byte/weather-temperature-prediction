import React, { useState } from 'react';
import { FileDown, Loader2 } from 'lucide-react';
import { DatasetSummary, ModelEvaluation, PredictionResult } from '../types';
import { DynamicInsightItem } from '../utils/insights';
import { generateWeatherPredictionPDF } from '../utils/reportGenerator';

interface ReportButtonProps {
  datasetSummary: DatasetSummary | null;
  prediction: PredictionResult | null;
  linearEval: ModelEvaluation | null;
  rfEval: ModelEvaluation | null;
  selectedModelName: 'Linear Regression' | 'Random Forest';
  insights: DynamicInsightItem[];
  modelReady: boolean;
  className?: string;
}

export const ReportButton: React.FC<ReportButtonProps> = ({
  datasetSummary,
  prediction,
  linearEval,
  rfEval,
  selectedModelName,
  insights,
  modelReady,
  className = '',
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleDownload = async () => {
    if (!modelReady || !datasetSummary) {
      setErrorMessage('Train the model before generating the report.');
      setTimeout(() => setErrorMessage(null), 4000);
      return;
    }

    try {
      setIsGenerating(true);
      setErrorMessage(null);

      // Attempt to capture current dashboard or analytics container if visible
      const reportTarget = document.getElementById('report-capture-zone');

      await generateWeatherPredictionPDF({
        datasetSummary,
        prediction,
        linearEval,
        rfEval,
        selectedModelName,
        insights,
        containerElementToCapture: reportTarget,
      });
    } catch (err) {
      console.error('PDF generation error:', err);
      setErrorMessage('Unable to generate report. Please try again.');
      setTimeout(() => setErrorMessage(null), 4000);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="relative inline-flex flex-col items-end">
      <button
        id="download-report-btn"
        onClick={handleDownload}
        disabled={isGenerating || !datasetSummary}
        className={`inline-flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-medium transition-all shadow-xs ${
          isGenerating || !datasetSummary
            ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
            : 'bg-slate-900 text-white hover:bg-slate-800 active:scale-[0.98]'
        } ${className}`}
        title="Generate and download comprehensive PDF report client-side"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin text-sky-400" />
            <span>Generating PDF...</span>
          </>
        ) : (
          <>
            <FileDown className="w-4 h-4 text-sky-400" />
            <span>Download Report</span>
          </>
        )}
      </button>

      {errorMessage && (
        <div
          id="report-error-alert"
          className="absolute top-full mt-2 right-0 z-50 w-64 p-2.5 bg-rose-50 text-rose-700 text-xs rounded-lg border border-rose-200 shadow-md animate-in fade-in slide-in-from-top-1"
        >
          {errorMessage}
        </div>
      )}
    </div>
  );
};
