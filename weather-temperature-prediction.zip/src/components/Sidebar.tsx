import React from 'react';
import {
  LayoutDashboard,
  ThermometerSnowflake,
  LineChart,
  Binary,
  CloudSun,
  X,
  Database,
  CheckCircle2,
} from 'lucide-react';

export type NavSection = 'dashboard' | 'predictor' | 'analysis' | 'performance';

interface SidebarProps {
  activeSection?: NavSection | string;
  currentSection?: NavSection | string;
  onSelectSection: (section: NavSection) => void;
  isOpenMobile?: boolean;
  isOpen?: boolean;
  onCloseMobile?: () => void;
  onClose?: () => void;
  totalRecords?: number;
  modelReady?: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  currentSection,
  onSelectSection,
  isOpenMobile,
  isOpen,
  onCloseMobile,
  onClose,
  totalRecords = 0,
  modelReady = false,
}) => {
  const current = ((activeSection || currentSection || 'dashboard') as NavSection);
  const isDrawerOpen = isOpenMobile ?? isOpen ?? false;
  const handleCloseDrawer = onCloseMobile || onClose || (() => {});
  const navItems = [
    {
      id: 'dashboard' as NavSection,
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'Overview & statistics',
    },
    {
      id: 'predictor' as NavSection,
      label: 'Temperature Predictor',
      icon: ThermometerSnowflake,
      description: 'Estimate new conditions',
    },
    {
      id: 'analysis' as NavSection,
      label: 'Weather Analysis',
      icon: LineChart,
      description: 'Explorer & distributions',
    },
    {
      id: 'performance' as NavSection,
      label: 'Model Performance',
      icon: Binary,
      description: 'Metrics & comparisons',
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isDrawerOpen && (
        <div
          id="mobile-sidebar-backdrop"
          onClick={handleCloseDrawer}
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden transition-opacity"
        />
      )}

      {/* Sidebar Container */}
      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-slate-900 text-slate-100 flex flex-col border-r border-slate-800 transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isDrawerOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-sky-500/20">
              <CloudSun className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-semibold text-base text-white tracking-tight leading-none">
                WeatherML
              </h1>
              <p className="text-xs text-slate-400 mt-1">Temperature Predictor</p>
            </div>
          </div>
          <button
            id="close-mobile-sidebar-btn"
            onClick={handleCloseDrawer}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            aria-label="Close navigation"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
          <div className="px-3 pb-2 text-[11px] font-medium tracking-wider uppercase text-slate-400">
            Navigation
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = current === item.id;
            return (
              <button
                key={item.id}
                id={`nav-btn-${item.id}`}
                onClick={() => {
                  onSelectSection(item.id);
                  handleCloseDrawer();
                }}
                className={`w-full flex items-center space-x-3 px-3.5 py-3 rounded-xl text-left transition-colors group ${
                  isActive
                    ? 'bg-sky-600 text-white font-medium shadow-sm shadow-sky-600/30'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <Icon
                  className={`w-5 h-5 shrink-0 ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium leading-none">{item.label}</div>
                  <div
                    className={`text-xs mt-1 truncate ${
                      isActive ? 'text-sky-100' : 'text-slate-400'
                    }`}
                  >
                    {item.description}
                  </div>
                </div>
              </button>
            );
          })}
        </nav>

        {/* Dataset & Model Status Card */}
        <div className="p-4 m-4 rounded-xl bg-slate-800/80 border border-slate-700/60">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-300 flex items-center space-x-1.5">
              <Database className="w-3.5 h-3.5 text-sky-400" />
              <span>Dataset Loaded</span>
            </span>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-700 text-slate-200 font-mono">
              {totalRecords} rows
            </span>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-700/50">
            <span>Regression Engine</span>
            {modelReady ? (
              <span className="inline-flex items-center text-emerald-400 text-[11px] font-medium space-x-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Ready</span>
              </span>
            ) : (
              <span className="text-amber-400 text-[11px]">Training...</span>
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="px-6 py-4 border-t border-slate-800 text-[11px] text-slate-400">
          <div>Client-Side ML • TensorFlow.js</div>
          <div className="text-slate-400 mt-0.5">Chronological 80/20 Partition</div>
        </div>
      </aside>
    </>
  );
};
