import React from 'react';

interface ChartCardProps {
  id: string;
  title: string;
  subtitle?: string;
  badge?: string;
  children: React.ReactNode;
  headerRight?: React.ReactNode;
  className?: string;
}

export const ChartCard: React.FC<ChartCardProps> = ({
  id,
  title,
  subtitle,
  badge,
  children,
  headerRight,
  className = '',
}) => {
  return (
    <div
      id={id}
      className={`p-5 sm:p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col ${className}`}
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-2 border-b border-slate-100">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-sm sm:text-base font-semibold text-slate-900 tracking-tight">
              {title}
            </h2>
            {badge && (
              <span className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-slate-100 text-slate-700 border border-slate-200">
                {badge}
              </span>
            )}
          </div>
          {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
        </div>

        {headerRight && <div className="shrink-0">{headerRight}</div>}
      </div>

      <div className="flex-1 w-full min-h-[260px] flex items-center justify-center">
        {children}
      </div>
    </div>
  );
};
