import React from 'react';
import {
  X,
  Thermometer,
  Droplets,
  Gauge,
  Wind,
  Cloud,
  CloudRain,
  Calendar,
  Clock,
  TrendingUp,
  TrendingDown,
  Minus,
} from 'lucide-react';
import { CleanWeatherRecord } from '../types';
import { getTemperatureCategory } from '../utils/weatherAnalysis';

interface WeatherDetailsProps {
  record: CleanWeatherRecord | null;
  onClose: () => void;
}

export const WeatherDetails: React.FC<WeatherDetailsProps> = ({ record, onClose }) => {
  if (!record) return null;

  const category = getTemperatureCategory(record.temperature);
  const tempDiff = record.tempChange;

  return (
    <div
      id="weather-record-details-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in"
    >
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div>
            <span className="text-xs font-mono font-semibold text-sky-600 bg-sky-50 px-2 py-0.5 rounded-md border border-sky-200">
              {record.record_id}
            </span>
            <h3 className="text-base font-semibold text-slate-900 mt-1">Weather Record Details</h3>
          </div>
          <button
            id="close-record-details-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Main Temperature Highlight */}
          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900 text-white">
            <div>
              <span className="text-xs text-slate-400 uppercase tracking-wider">Recorded Temperature</span>
              <div className="text-3xl font-bold mt-0.5">{record.temperature}°C</div>
            </div>
            <div className="text-right">
              <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-semibold border ${category.badgeClass}`}>
                {category.label}
              </span>
              <div className="flex items-center space-x-1 text-xs text-slate-300 mt-1.5 justify-end">
                {tempDiff > 0 ? (
                  <>
                    <TrendingUp className="w-3.5 h-3.5 text-rose-400" />
                    <span>+{tempDiff}°C vs previous</span>
                  </>
                ) : tempDiff < 0 ? (
                  <>
                    <TrendingDown className="w-3.5 h-3.5 text-sky-400" />
                    <span>{tempDiff}°C vs previous</span>
                  </>
                ) : (
                  <>
                    <Minus className="w-3.5 h-3.5 text-slate-400" />
                    <span>No delta vs previous</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Environmental metrics grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center space-x-1.5 text-xs text-slate-500">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Date & Season</span>
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">{record.date}</div>
              <div className="text-[11px] text-slate-500">{record.season}</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center space-x-1.5 text-xs text-slate-500">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Observation Time</span>
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">{record.time}</div>
              <div className="text-[11px] text-slate-500">Hour {record.hour}:00</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center space-x-1.5 text-xs text-slate-500">
                <Thermometer className="w-3.5 h-3.5 text-rose-500" />
                <span>Previous Temp</span>
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">{record.previous_temperature}°C</div>
              <div className="text-[11px] text-slate-500">Baseline reading</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center space-x-1.5 text-xs text-slate-500">
                <Droplets className="w-3.5 h-3.5 text-sky-500" />
                <span>Relative Humidity</span>
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">{record.humidity}%</div>
              <div className="text-[11px] text-slate-500">Vapor saturation</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center space-x-1.5 text-xs text-slate-500">
                <Gauge className="w-3.5 h-3.5 text-indigo-500" />
                <span>Atmospheric Pressure</span>
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">{record.pressure} hPa</div>
              <div className="text-[11px] text-slate-500">Barometric level</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center space-x-1.5 text-xs text-slate-500">
                <Wind className="w-3.5 h-3.5 text-teal-500" />
                <span>Wind Velocity</span>
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">{record.wind_speed} km/h</div>
              <div className="text-[11px] text-slate-500">Surface wind</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center space-x-1.5 text-xs text-slate-500">
                <Cloud className="w-3.5 h-3.5 text-slate-400" />
                <span>Cloud Cover</span>
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">{record.cloud_cover}%</div>
              <div className="text-[11px] text-slate-500">Sky coverage</div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <div className="flex items-center space-x-1.5 text-xs text-slate-500">
                <CloudRain className="w-3.5 h-3.5 text-blue-500" />
                <span>Precipitation</span>
              </div>
              <div className="text-sm font-semibold text-slate-800 mt-1">{record.precipitation} mm</div>
              <div className="text-[11px] text-slate-500">Rainfall depth</div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            id="dismiss-record-details-modal-btn"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-900 text-white hover:bg-slate-800 transition-colors"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
