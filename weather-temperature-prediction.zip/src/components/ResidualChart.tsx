import React, { useState } from "react";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  ReferenceLine,
  Cell,
} from "recharts";
import { ModelEvaluation } from "../types";
import { ChartCard } from "./ChartCard";
import { Scale, CheckCircle2, AlertTriangle } from "lucide-react";

interface ResidualChartProps {
  linearEval: ModelEvaluation | null;
  rfEval: ModelEvaluation | null;
}

export const ResidualChart: React.FC<ResidualChartProps> = ({ linearEval, rfEval }) => {
  const [selectedModel, setSelectedModel] = useState<"Random Forest" | "Linear Regression">("Random Forest");

  const currentEval = selectedModel === "Random Forest" ? rfEval : linearEval;

  if (!currentEval) {
    return (
      <div className="p-8 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
        Evaluation data loading...
      </div>
    );
  }

  const scatterData = currentEval.testPredictions.map((p) => ({
    actual: p.actual,
    predicted: p.predicted,
    residual: p.residual,
    date: p.date,
    recordId: p.recordId,
  }));

  const allTemps = scatterData.flatMap((d) => [d.actual, d.predicted]);
  const minTemp = Math.floor(Math.min(...allTemps, 0) - 2);
  const maxTemp = Math.ceil(Math.max(...allTemps, 30) + 2);

  const residuals = scatterData.map((d) => d.residual);
  const binRanges = [
    { label: "< -3°C", min: -Infinity, max: -3 },
    { label: "-3 to -2°C", min: -3, max: -2 },
    { label: "-2 to -1°C", min: -2, max: -1 },
    { label: "-1 to 0°C", min: -1, max: 0 },
    { label: "0 to +1°C", min: 0, max: 1 },
    { label: "+1 to +2°C", min: 1, max: 2 },
    { label: "+2 to +3°C", min: 2, max: 3 },
    { label: "> +3°C", min: 3, max: Infinity },
  ];

  const residualHistogram = binRanges.map((bin) => ({
    range: bin.label,
    count: residuals.filter((r) => r >= bin.min && r < bin.max).length,
    isNearZero: bin.label.includes("0"),
  }));

  const { residualStats } = currentEval;

  return (
    <div id="residual-diagnostics-section" className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white border border-slate-200/80">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-sky-50 text-sky-700">
            <Scale className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Active Evaluation Architecture: {selectedModel}
            </h3>
            <p className="text-xs text-slate-500">
              Visualizing {scatterData.length} chronological test partition predictions
            </p>
          </div>
        </div>

        <div className="flex items-center p-1 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => setSelectedModel("Random Forest")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              selectedModel === "Random Forest"
                ? "bg-white text-slate-900 shadow-xs"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Random Forest
          </button>
          <button
            type="button"
            onClick={() => setSelectedModel("Linear Regression")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              selectedModel === "Linear Regression"
                ? "bg-white text-slate-900 shadow-xs"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Linear Regression
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard
          id="actual-vs-predicted-chart"
          title="Actual vs Predicted Temperature"
          subtitle="Points near the 45° diagonal parity reference line represent near-perfect estimation"
          badge={selectedModel}
        >
          <ResponsiveContainer width="100%" height={320}>
            <ScatterChart margin={{ top: 15, right: 20, bottom: 25, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis
                type="number"
                dataKey="actual"
                name="Actual Temperature"
                unit="°C"
                domain={[minTemp, maxTemp]}
                label={{
                  value: "Actual Temperature (°C)",
                  position: "bottom",
                  offset: 12,
                  style: { fontSize: 11, fill: "#64748b" },
                }}
                tick={{ fontSize: 11, fill: "#64748b" }}
              />
              <YAxis
                type="number"
                dataKey="predicted"
                name="Predicted Temperature"
                unit="°C"
                domain={[minTemp, maxTemp]}
                label={{
                  value: "Predicted Temperature (°C)",
                  angle: -90,
                  position: "insideLeft",
                  offset: 0,
                  style: { fontSize: 11, fill: "#64748b" },
                }}
                tick={{ fontSize: 11, fill: "#64748b" }}
              />
              <Tooltip
                cursor={{ strokeDasharray: "3 3" }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="p-3 bg-slate-900 text-white text-xs rounded-xl shadow-lg border border-slate-800 space-y-1">
                        <div className="font-semibold text-sky-400 font-mono">{data.recordId}</div>
                        <div className="text-slate-300 text-[11px]">{data.date}</div>
                        <div className="pt-1 border-t border-slate-800">
                          <div>Actual: <span className="font-bold text-white">{data.actual}°C</span></div>
                          <div>Predicted: <span className="font-bold text-emerald-400">{data.predicted}°C</span></div>
                          <div className="text-[11px] text-slate-400">
                            Residual: {data.residual > 0 ? `+${data.residual}` : data.residual}°C
                          </div>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <ReferenceLine
                segment={[
                  { x: minTemp, y: minTemp },
                  { x: maxTemp, y: maxTemp },
                ]}
                stroke="#0284c7"
                strokeWidth={1.5}
                strokeDasharray="4 4"
                label={{
                  value: "Ideal Parity (y = x)",
                  position: "insideTopLeft",
                  style: { fontSize: 10, fill: "#0284c7" },
                }}
              />
              <Scatter
                name="Test Observations"
                data={scatterData}
                fill="#0284c7"
                fillOpacity={0.7}
                stroke="#0369a1"
                strokeWidth={1}
              />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard
          id="residual-distribution-chart"
          title="Residual Distribution (Error Analysis)"
          subtitle="Residual = Actual - Predicted; symmetrical clustering at 0 indicates unbiased predictions"
          badge="Error Profile"
        >
          <div className="w-full space-y-4">
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={residualHistogram} margin={{ top: 10, right: 10, bottom: 25, left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="range"
                  tick={{ fontSize: 10, fill: "#64748b" }}
                  interval={0}
                  angle={-20}
                  textAnchor="end"
                />
                <YAxis tick={{ fontSize: 11, fill: "#64748b" }} />
                <Tooltip
                  formatter={(val: any) => [`${val} test samples`, "Frequency"]}
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    border: "none",
                    borderRadius: "0.75rem",
                    color: "#fff",
                    fontSize: "12px",
                  }}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {residualHistogram.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.isNearZero ? "#0284c7" : "#94a3b8"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 text-center">
                <span className="text-[11px] text-slate-500 block">Mean Residual</span>
                <span className="font-bold text-slate-900 font-mono">
                  {residualStats.meanResidual > 0 ? `+${residualStats.meanResidual}` : residualStats.meanResidual}°C
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 text-center">
                <span className="text-[11px] text-slate-500 block">Underpredicted (&gt;0)</span>
                <span className="font-bold text-amber-600 font-mono">
                  {residualStats.positiveCount}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 text-center">
                <span className="text-[11px] text-slate-500 block">Overpredicted (&lt;0)</span>
                <span className="font-bold text-sky-600 font-mono">
                  {residualStats.negativeCount}
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-2 px-3 py-2 rounded-xl bg-slate-50 text-xs text-slate-700 border border-slate-100">
              {residualStats.biasAssessment.includes("Well-Calibrated") ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              )}
              <span className="font-medium">{residualStats.biasAssessment}</span>
            </div>
          </div>
        </ChartCard>
      </div>
    </div>
  );
};
