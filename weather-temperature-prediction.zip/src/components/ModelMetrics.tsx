import React from "react";
import { Award } from "lucide-react";
import { ModelEvaluation } from "../types";

interface ModelMetricsProps {
  linearEval: ModelEvaluation | null;
  rfEval: ModelEvaluation | null;
}

export const ModelMetrics: React.FC<ModelMetricsProps> = ({ linearEval, rfEval }) => {
  if (!linearEval || !rfEval) {
    return (
      <div className="p-6 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
        Regression models are training...
      </div>
    );
  }

  const lMetrics = linearEval.metrics;
  const rfMetrics = rfEval.metrics;

  const maeWinner = rfMetrics.mae <= lMetrics.mae ? "rf" : "linear";
  const mseWinner = rfMetrics.mse <= lMetrics.mse ? "rf" : "linear";
  const rmseWinner = rfMetrics.rmse <= lMetrics.rmse ? "rf" : "linear";
  const r2Winner = rfMetrics.r2 >= lMetrics.r2 ? "rf" : "linear";

  const overallWinner =
    rfMetrics.rmse <= lMetrics.rmse && rfMetrics.r2 >= lMetrics.r2
      ? "Random Forest"
      : lMetrics.rmse <= rfMetrics.rmse && lMetrics.r2 >= rfMetrics.r2
      ? "Linear Regression"
      : rfMetrics.rmse < lMetrics.rmse
      ? "Random Forest"
      : "Linear Regression";

  return (
    <div id="model-metrics-comparison-container" className="space-y-6">
      <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200/80 flex items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-emerald-600 text-white shadow-xs">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
              Top Performing Architecture
            </div>
            <div className="text-sm font-bold text-slate-900 mt-0.5">
              {overallWinner} demonstrates superior generalization on the chronological test partition
            </div>
          </div>
        </div>
        <span className="hidden sm:inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
          Optimal Choice
        </span>
      </div>

      <div className="rounded-2xl border border-slate-200/80 bg-white overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Regression Metrics Comparison (Test Partition)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Evaluated strictly on the held-out chronological 20% validation split
            </p>
          </div>
          <span className="text-xs text-slate-500 font-mono">20% Holdout Split</span>
        </div>

        <div className="overflow-x-auto">
          <table id="model-comparison-table" className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50/80 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-6 py-3.5">Metric</th>
                <th className="px-6 py-3.5">Criterion</th>
                <th className="px-6 py-3.5">Linear Regression</th>
                <th className="px-6 py-3.5">Random Forest</th>
                <th className="px-6 py-3.5 text-right">Advantage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              <tr className="hover:bg-slate-50/60 transition-colors">
                <td className="px-6 py-4 font-semibold text-slate-900">
                  MAE (Mean Absolute Error)
                </td>
                <td className="px-6 py-4 text-xs text-slate-500">Lower is better</td>
                <td className="px-6 py-4 font-mono font-medium">
                  {lMetrics.mae}°C
                  {maeWinner === "linear" && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                      Best
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 font-mono font-medium">
                  {rfMetrics.mae}°C
                  {maeWinner === "rf" && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                      Best
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  <span className="font-medium text-xs text-emerald-700">
                    {maeWinner === "rf" ? "Random Forest" : "Linear Regression"} (Δ{" "}
                    {Math.abs(lMetrics.mae - rfMetrics.mae).toFixed(3)}°C)
                  </span>
                </td>
              </tr>

              <tr className="hover:bg-slate-50/60 transition-colors">
                <td className="px-6 py-4 font-semibold text-slate-900">
                  MSE (Mean Squared Error)
                </td>
                <td className="px-6 py-4 text-xs text-slate-500">Lower is better</td>
                <td className="px-6 py-4 font-mono font-medium">
                  {lMetrics.mse}
                  {mseWinner === "linear" && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                      Best
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 font-mono font-medium">
                  {rfMetrics.mse}
                  {mseWinner === "rf" && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                      Best
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  <span className="font-medium text-xs text-emerald-700">
                    {mseWinner === "rf" ? "Random Forest" : "Linear Regression"} (Δ{" "}
                    {Math.abs(lMetrics.mse - rfMetrics.mse).toFixed(3)})
                  </span>
                </td>
              </tr>

              <tr className="hover:bg-slate-50/60 transition-colors">
                <td className="px-6 py-4 font-semibold text-slate-900">
                  RMSE (Root Mean Squared Error)
                </td>
                <td className="px-6 py-4 text-xs text-slate-500">Lower is better</td>
                <td className="px-6 py-4 font-mono font-medium">
                  {lMetrics.rmse}°C
                  {rmseWinner === "linear" && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                      Best
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 font-mono font-medium">
                  {rfMetrics.rmse}°C
                  {rmseWinner === "rf" && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                      Best
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  <span className="font-medium text-xs text-emerald-700">
                    {rmseWinner === "rf" ? "Random Forest" : "Linear Regression"} (Δ{" "}
                    {Math.abs(lMetrics.rmse - rfMetrics.rmse).toFixed(3)}°C)
                  </span>
                </td>
              </tr>

              <tr className="hover:bg-slate-50/60 transition-colors">
                <td className="px-6 py-4 font-semibold text-slate-900">
                  R² (Coefficient of Determination)
                </td>
                <td className="px-6 py-4 text-xs text-slate-500">Higher is better (Max 1.0)</td>
                <td className="px-6 py-4 font-mono font-medium">
                  {lMetrics.r2}
                  {r2Winner === "linear" && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                      Best
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 font-mono font-medium">
                  {rfMetrics.r2}
                  {r2Winner === "rf" && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-100 text-emerald-700">
                      Best
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  <span className="font-medium text-xs text-emerald-700">
                    {r2Winner === "rf" ? "Random Forest" : "Linear Regression"} (Δ{" "}
                    {Math.abs(lMetrics.r2 - rfMetrics.r2).toFixed(3)})
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
