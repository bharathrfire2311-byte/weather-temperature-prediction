import React from 'react';
import { Menu, Thermometer, Sparkles } from 'lucide-react';
import { ReportButton } from './ReportButton';
import { DatasetSummary, ModelEvaluation, PredictionResult } from '../types';
import { DynamicInsightItem } from '../utils/insights';
import { NavSection } from './Sidebar';

interface HeaderProps {
  currentSection?: NavSection;
  activeSection?: NavSection | string;
  onOpenMobileMenu?: () => void;
  onToggleSidebar?: () => void;
  datasetSummary?: DatasetSummary | null;
  summary?: DatasetSummary | null;
  prediction?: PredictionResult | null;
  linearEval?: ModelEvaluation | null;
  rfEval?: ModelEvaluation | null;
  selectedModelName?: 'Linear Regression' | 'Random Forest';
  insights?: DynamicInsightItem[] | any[];
  modelReady?: boolean;
}

const SECTION_TITLES: Record<NavSection, { title: string; subtitle: string }> = {
  dashboard: {
    title: 'Weather Analytics Dashboard',
    subtitle: 'Historical observations, statistical distributions, and climate trends',
  },
  predictor: {
    title: 'Temperature Predictor',
    subtitle: 'Machine learning inference for novel weather observation vectors',
  },
  analysis: {
    title: 'Detailed Weather Analysis',
    subtitle: 'Parametric breakdown, historical explorer, and variable relationships',
  },
  performance: {
    title: 'Regression Model Performance',
    subtitle: 'Evaluation metrics, actual vs predicted scatter, and residual diagnostics',
  },
};

export const Header: React.FC<HeaderProps> = ({
  currentSection,
  activeSection,
  onOpenMobileMenu,
  onToggleSidebar,
  datasetSummary,
  summary,
  prediction = null,
  linearEval = null,
  rfEval = null,
  selectedModelName = 'Random Forest',
  insights = [],
  modelReady = false,
}) => {
  const effectiveSection = ((currentSection || activeSection || 'dashboard') as NavSection);
  const sectionMeta = SECTION_TITLES[effectiveSection] || SECTION_TITLES.dashboard;
  const { title, subtitle } = sectionMeta;

  const handleMobileMenu = onOpenMobileMenu || onToggleSidebar || (() => {});
  const effectiveSummary = datasetSummary || summary || null;
  const isModelReady = modelReady || (!!linearEval && !!rfEval);

  return (
    <header
      id="main-app-header"
      className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-8 py-3.5"
    >
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile Menu & Titles */}
        <div className="flex items-center space-x-3.5 min-w-0">
          <button
            id="mobile-nav-toggle-btn"
            onClick={handleMobileMenu}
            className="lg:hidden p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
            aria-label="Open mobile navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="min-w-0">
            <h1 className="text-base sm:text-lg font-semibold text-slate-900 tracking-tight truncate">
              {title}
            </h1>
            <p className="text-xs text-slate-500 hidden sm:block truncate">{subtitle}</p>
          </div>
        </div>

        {/* Right: Badges and Actions */}
        <div className="flex items-center space-x-2.5 sm:space-x-3 shrink-0">
          {/* Temperature Unit Badge */}
          <div
            id="temp-unit-indicator"
            className="hidden md:inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-xs font-medium text-slate-700"
          >
            <Thermometer className="w-3.5 h-3.5 text-sky-600" />
            <span>Unit: Celsius (°C)</span>
          </div>

          {/* Training status */}
          <div
            id="model-status-indicator"
            className={`hidden sm:inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border ${
              isModelReady
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : 'bg-amber-50 text-amber-700 border-amber-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isModelReady ? 'ML Models Active' : 'Training ML Models...'}</span>
          </div>

          {/* Download PDF Report Button */}
          <ReportButton
            datasetSummary={effectiveSummary}
            prediction={prediction}
            linearEval={linearEval}
            rfEval={rfEval}
            selectedModelName={selectedModelName}
            insights={insights}
            modelReady={isModelReady}
          />
        </div>
      </div>
    </header>
  );
};
