import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  Calendar,
} from 'lucide-react';
import { CleanWeatherRecord, Season } from '../types';
import { SEASONS } from '../ml/encoding';
import { getTemperatureCategory } from '../utils/weatherAnalysis';

interface WeatherTableProps {
  records: CleanWeatherRecord[];
  onSelectRecord: (record: CleanWeatherRecord) => void;
}

type SortField = 'record_id' | 'date' | 'temperature' | 'previous_temperature' | 'humidity' | 'pressure' | 'wind_speed' | 'season';

export const WeatherTable: React.FC<WeatherTableProps> = ({ records, onSelectRecord }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSeason, setSelectedSeason] = useState<string>('All');
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const filteredAndSorted = useMemo(() => {
    let result = [...records];

    // Filter by season
    if (selectedSeason !== 'All') {
      result = result.filter((r) => r.season === selectedSeason);
    }

    // Filter by search term
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (r) =>
          r.record_id.toLowerCase().includes(q) ||
          r.date.toLowerCase().includes(q) ||
          r.time.toLowerCase().includes(q) ||
          r.season.toLowerCase().includes(q)
      );
    }

    // Sort
    result.sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];

      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase();
        bVal = (bVal as string).toLowerCase();
      }

      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [records, selectedSeason, searchTerm, sortField, sortDirection]);

  // Pagination calculation
  const totalPages = Math.max(1, Math.ceil(filteredAndSorted.length / pageSize));
  const validPage = Math.min(currentPage, totalPages);
  const paginatedRecords = useMemo(() => {
    const start = (validPage - 1) * pageSize;
    return filteredAndSorted.slice(start, start + pageSize);
  }, [filteredAndSorted, validPage, pageSize]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-3 h-3 text-slate-400" />;
    }
    return sortDirection === 'asc' ? (
      <ArrowUp className="w-3 h-3 text-sky-600 font-bold" />
    ) : (
      <ArrowDown className="w-3 h-3 text-sky-600 font-bold" />
    );
  };

  return (
    <div id="weather-explorer-table-container" className="space-y-4">
      {/* Controls Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            id="weather-table-search-input"
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search by ID, date, or season..."
            className="w-full pl-9 pr-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all bg-white"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center space-x-2.5">
          <div className="flex items-center space-x-1.5 text-xs text-slate-600">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span>Season:</span>
          </div>
          <select
            id="weather-table-season-filter"
            value={selectedSeason}
            onChange={(e) => {
              setSelectedSeason(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
          >
            <option value="All">All Seasons</option>
            {SEASONS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>

          {/* Page size selector */}
          <select
            id="weather-table-pagesize-select"
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
          >
            <option value={10}>10 / page</option>
            <option value={25}>25 / page</option>
            <option value={50}>50 / page</option>
          </select>
        </div>
      </div>

      {/* Table Container */}
      <div className="rounded-2xl border border-slate-200/80 bg-white shadow-xs overflow-hidden min-w-0">
        <div className="overflow-x-auto">
          <table id="weather-records-table" className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th
                  onClick={() => handleSort('record_id')}
                  className="px-4 py-3 cursor-pointer hover:bg-slate-100/70 select-none"
                >
                  <div className="flex items-center space-x-1.5">
                    <span>Record ID</span>
                    {renderSortIcon('record_id')}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('date')}
                  className="px-4 py-3 cursor-pointer hover:bg-slate-100/70 select-none"
                >
                  <div className="flex items-center space-x-1.5">
                    <span>Date & Time</span>
                    {renderSortIcon('date')}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('temperature')}
                  className="px-4 py-3 cursor-pointer hover:bg-slate-100/70 select-none"
                >
                  <div className="flex items-center space-x-1.5">
                    <span>Temperature</span>
                    {renderSortIcon('temperature')}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('previous_temperature')}
                  className="px-4 py-3 cursor-pointer hover:bg-slate-100/70 select-none hidden md:table-cell"
                >
                  <div className="flex items-center space-x-1.5">
                    <span>Prev Temp</span>
                    {renderSortIcon('previous_temperature')}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('humidity')}
                  className="px-4 py-3 cursor-pointer hover:bg-slate-100/70 select-none"
                >
                  <div className="flex items-center space-x-1.5">
                    <span>Humidity</span>
                    {renderSortIcon('humidity')}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('pressure')}
                  className="px-4 py-3 cursor-pointer hover:bg-slate-100/70 select-none hidden sm:table-cell"
                >
                  <div className="flex items-center space-x-1.5">
                    <span>Pressure</span>
                    {renderSortIcon('pressure')}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('wind_speed')}
                  className="px-4 py-3 cursor-pointer hover:bg-slate-100/70 select-none hidden lg:table-cell"
                >
                  <div className="flex items-center space-x-1.5">
                    <span>Wind Speed</span>
                    {renderSortIcon('wind_speed')}
                  </div>
                </th>
                <th
                  onClick={() => handleSort('season')}
                  className="px-4 py-3 cursor-pointer hover:bg-slate-100/70 select-none"
                >
                  <div className="flex items-center space-x-1.5">
                    <span>Season</span>
                    {renderSortIcon('season')}
                  </div>
                </th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-normal">
              {paginatedRecords.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-8 text-center text-slate-400">
                    No matching weather records found.
                  </td>
                </tr>
              ) : (
                paginatedRecords.map((r) => {
                  const cat = getTemperatureCategory(r.temperature);
                  return (
                    <tr
                      key={r.record_id}
                      onClick={() => onSelectRecord(r)}
                      className="hover:bg-sky-50/40 cursor-pointer transition-colors"
                    >
                      <td className="px-4 py-3 font-mono font-medium text-sky-700 text-xs">
                        {r.record_id}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="font-medium text-slate-900">{r.date}</span>{' '}
                        <span className="text-slate-400 text-xs">({r.time})</span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-slate-900">{r.temperature}°C</span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${cat.badgeClass}`}
                          >
                            {cat.label}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-600 hidden md:table-cell">
                        {r.previous_temperature}°C
                      </td>
                      <td className="px-4 py-3 text-slate-700">{r.humidity}%</td>
                      <td className="px-4 py-3 text-slate-700 hidden sm:table-cell">
                        {r.pressure} hPa
                      </td>
                      <td className="px-4 py-3 text-slate-700 hidden lg:table-cell">
                        {r.wind_speed} km/h
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-2.5 py-0.5 rounded-md text-xs font-medium bg-slate-100 text-slate-700">
                          {r.season}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectRecord(r);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-sky-600 hover:bg-sky-50 transition-colors"
                          title="View Record Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Pagination */}
        <div className="flex flex-col sm:flex-row items-center justify-between px-4 py-3 border-t border-slate-100 bg-slate-50/50 gap-2 text-xs text-slate-600">
          <div>
            Showing <span className="font-semibold text-slate-800">{paginatedRecords.length}</span> of{' '}
            <span className="font-semibold text-slate-800">{filteredAndSorted.length}</span> records
            {filteredAndSorted.length !== records.length && ` (filtered from ${records.length} total)`}
          </div>

          <div className="flex items-center space-x-1.5">
            <button
              id="weather-table-prev-page-btn"
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={validPage <= 1}
              className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2.5 py-1 text-slate-700 font-medium">
              Page {validPage} of {totalPages}
            </span>
            <button
              id="weather-table-next-page-btn"
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={validPage >= totalPages}
              className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
