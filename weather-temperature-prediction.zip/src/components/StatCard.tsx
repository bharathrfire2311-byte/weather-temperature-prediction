import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  id: string;
  title: string;
  value: string | number;
  unit?: string;
  icon: LucideIcon | React.ReactNode;
  subtitle?: string;
  badge?: string;
  colorScheme?: 'sky' | 'emerald' | 'amber' | 'indigo' | 'rose' | 'slate';
}

export const StatCard: React.FC<StatCardProps> = ({
  id,
  title,
  value,
  unit,
  icon,
  subtitle,
  badge,
  colorScheme = 'slate',
}) => {
  const colorStyles = {
    sky: {
      bg: 'bg-sky-50/50',
      iconBg: 'bg-sky-100 text-sky-700',
      badge: 'bg-sky-100 text-sky-800 border-sky-200',
    },
    emerald: {
      bg: 'bg-emerald-50/50',
      iconBg: 'bg-emerald-100 text-emerald-700',
      badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    },
    amber: {
      bg: 'bg-amber-50/50',
      iconBg: 'bg-amber-100 text-amber-700',
      badge: 'bg-amber-100 text-amber-800 border-amber-200',
    },
    indigo: {
      bg: 'bg-indigo-50/50',
      iconBg: 'bg-indigo-100 text-indigo-700',
      badge: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    },
    rose: {
      bg: 'bg-rose-50/50',
      iconBg: 'bg-rose-100 text-rose-700',
      badge: 'bg-rose-100 text-rose-800 border-rose-200',
    },
    slate: {
      bg: 'bg-white',
      iconBg: 'bg-slate-100 text-slate-700',
      badge: 'bg-slate-100 text-slate-700 border-slate-200',
    },
  }[colorScheme];

  return (
    <div
      id={id}
      className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-slate-300 transition-colors"
    >
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{title}</p>
          <div className="flex items-baseline space-x-1.5 pt-0.5">
            <span className="text-2xl font-bold tracking-tight text-slate-900">{value}</span>
            {unit && <span className="text-xs font-medium text-slate-500">{unit}</span>}
          </div>
        </div>

        <div className={`p-2.5 rounded-xl ${colorStyles.iconBg} flex items-center justify-center shrink-0`}>
          {React.isValidElement(icon) ? (
            icon
          ) : typeof icon === 'function' || (typeof icon === 'object' && icon !== null && 'render' in (icon as any)) ? (
            React.createElement(icon as React.ComponentType<{ className?: string }>, { className: 'w-5 h-5' })
          ) : null}
        </div>
      </div>

      {(subtitle || badge) && (
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
          {subtitle && <span className="text-slate-500 truncate">{subtitle}</span>}
          {badge && (
            <span className={`px-2 py-0.5 rounded-md font-medium text-[11px] border ${colorStyles.badge}`}>
              {badge}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
