import React, { useState, useEffect } from 'react';
import {
  RawWeatherRecord,
  CleanWeatherRecord,
  DatasetSummary,
  TrainedModels,
  ModelEvaluation,
  WeatherPredictionInput,
  PredictionResult,
  WeatherInsight,
} from './types';
import { fetchWeatherCSV } from './services/dataset';
import { preprocessDataset } from './ml/preprocessing';
import { trainAndEvaluateModels, predictTemperature } from './ml/modelTraining';
import { generateInsights } from './utils/insights';

import { Sidebar, NavSection } from './components/Sidebar';
import { Header } from './components/Header';
import { WeatherDetails } from './components/WeatherDetails';

import { Dashboard } from './pages/Dashboard';
import { TemperaturePredictor } from './pages/TemperaturePredictor';
import { WeatherAnalysis } from './pages/WeatherAnalysis';
import { ModelPerformance } from './pages/ModelPerformance';

export function App() {
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [rawRecords, setRawRecords] = useState<RawWeatherRecord[]>([]);
  const [cleanRecords, setCleanRecords] = useState<CleanWeatherRecord[]>([]);
  const [summary, setSummary] = useState<DatasetSummary | null>(null);

  const [trainedModels, setTrainedModels] = useState<TrainedModels | null>(null);
  const [linearEval, setLinearEval] = useState<ModelEvaluation | null>(null);
  const [rfEval, setRfEval] = useState<ModelEvaluation | null>(null);

  const [selectedModel, setSelectedModel] = useState<'Linear Regression' | 'Random Forest'>('Random Forest');
  const [currentPrediction, setCurrentPrediction] = useState<PredictionResult | null>(null);

  const [selectedRecordForDetails, setSelectedRecordForDetails] = useState<CleanWeatherRecord | null>(null);
  const [insights, setInsights] = useState<WeatherInsight[]>([]);

  const [isLoading, setIsLoading] = useState(true);
  const [statusMessage, setStatusMessage] = useState('Loading historical weather archive...');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function initializeSystem() {
      try {
        setIsLoading(true);
        setStatusMessage('Loading verified meteorological observations...');

        const rawResult = await fetchWeatherCSV();
        if (!isMounted) return;
        setRawRecords(rawResult.data);

        setStatusMessage('Preprocessing, validating, and cleaning weather observations...');
        const { cleanRecords: cleaned, summary: datasetSummary } = preprocessDataset(rawResult.data);
        if (!isMounted) return;
        setCleanRecords(cleaned);
        setSummary(datasetSummary);

        setStatusMessage('Training Linear Regression and Random Forest models on chronological split...');
        await new Promise((resolve) => setTimeout(resolve, 50));

        const artifacts = await trainAndEvaluateModels(cleaned);
        if (!isMounted) return;
        setTrainedModels(artifacts);
        setLinearEval(artifacts.linearEvaluation);
        setRfEval(artifacts.rfEvaluation);

        const dynamicInsights = generateInsights(
          datasetSummary,
          artifacts.linearEvaluation,
          artifacts.rfEvaluation,
          cleaned
        );
        setInsights(dynamicInsights);

        const initialPrediction = predictTemperature(
          {
            previous_temperature: 24.5,
            humidity: 48,
            pressure: 1013.0,
            wind_speed: 12.0,
            cloud_cover: 30,
            precipitation: 0.0,
            season: 'Summer',
            time: '14:00',
          },
          'Random Forest',
          artifacts,
          artifacts.rfEvaluation,
          artifacts.linearEvaluation
        );
        setCurrentPrediction(initialPrediction);

        setIsLoading(false);
      } catch (err: any) {
        console.error('System initialization failed:', err);
        if (isMounted) {
          setError(err?.message || 'Failed to initialize meteorological machine learning engine');
          setIsLoading(false);
        }
      }
    }

    initializeSystem();

    return () => {
      isMounted = false;
    };
  }, []);

  const handlePredict = (
    inputs: WeatherPredictionInput,
    modelType: 'Linear Regression' | 'Random Forest'
  ) => {
    if (!trainedModels) return;
    const result = predictTemperature(
      inputs,
      modelType,
      trainedModels,
      rfEval,
      linearEval
    );
    setCurrentPrediction(result);
  };

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 overflow-hidden font-sans antialiased">
      <Sidebar
        activeSection={activeSection}
        onSelectSection={(section) => {
          setActiveSection(section);
          setSidebarOpen(false);
        }}
        isOpenMobile={sidebarOpen}
        onCloseMobile={() => setSidebarOpen(false)}
        totalRecords={cleanRecords.length || summary?.validRecords || 0}
        modelReady={!!trainedModels}
      />

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          currentSection={activeSection}
          activeSection={activeSection}
          onOpenMobileMenu={() => setSidebarOpen(true)}
          onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
          datasetSummary={summary}
          summary={summary}
          prediction={currentPrediction}
          linearEval={linearEval}
          rfEval={rfEval}
          selectedModelName={selectedModel}
          insights={insights}
          modelReady={!!trainedModels}
        />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div id="report-capture-zone" className="max-w-7xl mx-auto space-y-8">
            {isLoading ? (
              <div className="min-h-[500px] flex flex-col items-center justify-center p-8 text-center space-y-4">
                <div className="w-12 h-12 rounded-2xl border-4 border-sky-200 border-t-sky-600 animate-spin" />
                <div>
                  <h3 className="text-base font-semibold text-slate-800">
                    Initializing Climate Intelligence Machine
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm">{statusMessage}</p>
                </div>
              </div>
            ) : error ? (
              <div className="p-8 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-center space-y-2">
                <h3 className="text-base font-bold">Initialization Error</h3>
                <p className="text-xs">{error}</p>
              </div>
            ) : (
              <>
                {activeSection === 'dashboard' && (
                  <Dashboard
                    summary={summary}
                    records={cleanRecords}
                    rfEval={rfEval}
                    linearEval={linearEval}
                    insights={insights}
                    onNavigateToPredictor={() => setActiveSection('predictor')}
                    onNavigateToAnalysis={() => setActiveSection('analysis')}
                    onNavigateToPerformance={() => setActiveSection('performance')}
                  />
                )}

                {activeSection === 'predictor' && (
                  <TemperaturePredictor
                    onPredict={handlePredict}
                    selectedModel={selectedModel}
                    onSelectModel={setSelectedModel}
                    prediction={currentPrediction}
                    rfEval={rfEval}
                    linearEval={linearEval}
                    isModelReady={!!trainedModels}
                  />
                )}

                {activeSection === 'analysis' && (
                  <WeatherAnalysis
                    records={cleanRecords}
                    summary={summary}
                    onSelectRecord={(rec) => setSelectedRecordForDetails(rec)}
                  />
                )}

                {activeSection === 'performance' && (
                  <ModelPerformance
                    linearEval={linearEval}
                    rfEval={rfEval}
                    insights={insights}
                  />
                )}
              </>
            )}
          </div>
        </main>
      </div>

      <WeatherDetails
        record={selectedRecordForDetails}
        onClose={() => setSelectedRecordForDetails(null)}
      />
    </div>
  );
}

export default App;
